-- ══════════════════════════════════════════════
-- Creator Factory Agent One — Supabase Schema
-- Run this in your Supabase SQL editor
-- ══════════════════════════════════════════════

-- Projects table
create table if not exists projects (
  id uuid default gen_random_uuid() primary key,
  user_id text not null,
  name text not null default 'Untitled Project',
  brain jsonb default '{}',
  scenes jsonb default '[]',
  assets jsonb default '[]',
  nodes jsonb default '[]',
  notebook text default '',
  skill text default 'shorts',
  credits_used float default 0,
  production_score int default 0,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

-- Messages table
create table if not exists messages (
  id uuid default gen_random_uuid() primary key,
  project_id uuid references projects(id) on delete cascade,
  role text not null,
  content text not null,
  type text default 'chat',
  metadata jsonb default '{}',
  created_at timestamptz default now()
);

-- Generations table (tracks all model generations)
create table if not exists generations (
  id uuid default gen_random_uuid() primary key,
  project_id uuid references projects(id) on delete cascade,
  scene_index int,
  model text not null,
  prompt text not null,
  status text default 'pending',
  result_url text,
  cost_credits float default 0,
  created_at timestamptz default now(),
  completed_at timestamptz
);

-- Trend cache table
create table if not exists trends (
  id uuid default gen_random_uuid() primary key,
  platform text not null,
  title text not null,
  hook text,
  views text,
  category text,
  fetched_at timestamptz default now()
);

-- Credits table
create table if not exists credits (
  id uuid default gen_random_uuid() primary key,
  user_id text not null unique,
  balance float default 10,
  total_purchased float default 0,
  updated_at timestamptz default now()
);

-- Enable realtime
alter publication supabase_realtime add table projects;
alter publication supabase_realtime add table messages;
alter publication supabase_realtime add table generations;

-- RLS policies (adjust for your auth setup)
alter table projects enable row level security;
alter table messages enable row level security;
alter table generations enable row level security;
alter table credits enable row level security;

create policy "Users can manage their projects"
  on projects for all using (true);

create policy "Users can manage their messages"
  on messages for all using (true);

create policy "Users can manage their generations"
  on generations for all using (true);

create policy "Users can manage their credits"
  on credits for all using (true);

-- Updated_at trigger
create or replace function update_updated_at()
returns trigger as $$
begin new.updated_at = now(); return new; end;
$$ language plpgsql;

create trigger projects_updated_at
  before update on projects
  for each row execute function update_updated_at();
