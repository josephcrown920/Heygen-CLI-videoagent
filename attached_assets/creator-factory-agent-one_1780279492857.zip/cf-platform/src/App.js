import { useState, useEffect, useRef, useCallback } from "react";
import { runAgentPipeline, runBrainstorm, fetchTrends, generateCaptions, generateVariants, scoreHook, buildClientExport, buildCapcutExport, callGemini, JOSH_CONTEXT } from "./lib/intelligence";
import { generateScene, generateVoiceover, generateFlux, getVoices } from "./lib/generation";
import { saveProject, loadProjects, loadProject, saveMessage, loadMessages, getCredits, deductCredits, trackGeneration, updateGeneration } from "./lib/db";

// ══════════════════════════════════════════════════════════
// CONSTANTS
// ══════════════════════════════════════════════════════════
const MODELS = {
  video: [
    { id: "veo3", name: "Veo 3.1", provider: "Google", best: "cinematic", color: "#4285f4" },
    { id: "sora2", name: "Sora 2", provider: "OpenAI", best: "storytelling", color: "#10a37f" },
    { id: "kling3", name: "Kling 3.0", provider: "fal.ai", best: "action/realism", color: "#ff6b35", live: true },
    { id: "seedance", name: "Seedance 2.0", provider: "fal.ai", best: "style", color: "#fe2c55", live: true },
    { id: "nanobanana", name: "Nano Banana Pro", provider: "NB", best: "fast/creative", color: "#f9ca24" },
    { id: "runway", name: "Runway Gen-3", provider: "Runway", best: "effects", color: "#8b5cf6" },
    { id: "haiper", name: "Haiper 2.0", provider: "Haiper", best: "smooth motion", color: "#06b6d4" },
    { id: "luma", name: "Luma Dream", provider: "Luma", best: "dreamlike", color: "#ec4899" },
  ],
  image: [
    { id: "flux", name: "FLUX Pro 1.1", provider: "fal.ai", best: "photorealism", color: "#f59e0b", live: true },
    { id: "ideogram", name: "Ideogram 3", provider: "Ideogram", best: "text in image", color: "#7c3aed" },
    { id: "midjourney", name: "Midjourney 7", provider: "MJ", best: "artistic", color: "#6366f1" },
  ],
  audio: [
    { id: "elevenlabs", name: "ElevenLabs v3", provider: "EL", best: "voiceover", color: "#00d4ff", live: true },
    { id: "musicgen", name: "MusicGen", provider: "Meta", best: "background", color: "#00ff88" },
    { id: "suno", name: "Suno v4", provider: "Suno", best: "full songs", color: "#ff4466" },
    { id: "udio", name: "Udio", provider: "Udio", best: "hip-hop/beats", color: "#a855f7" },
  ],
};

const CREATOR_SKILLS = [
  { id: "shorts", name: "YouTube Shorts", icon: "▶", desc: "Hook→story→CTA optimized for retention" },
  { id: "tiktok", name: "TikTok Viral", icon: "◈", desc: "Pattern interrupt, trend riding, sound sync" },
  { id: "music_video", name: "Music Video", icon: "♪", desc: "Lyric sync, visual metaphor, cuts" },
  { id: "ad", name: "Performance Ad", icon: "◎", desc: "AIDA framework, conversion-focused, A/B" },
  { id: "cinematic", name: "Cinematic Short", icon: "◉", desc: "Film language, color grade, score-driven" },
  { id: "ugc", name: "UGC / Avatar", icon: "◑", desc: "Authentic creator style, face-sync" },
  { id: "nft_reveal", name: "NFT Drop Reveal", icon: "⬡", desc: "Hype build, reveal mechanics, community hook" },
  { id: "product", name: "Product Launch", icon: "◇", desc: "Feature showcase, social proof, offer" },
];

const AGENTS = [
  { id: "director", name: "Director", color: "#00d4ff", icon: "◎" },
  { id: "script", name: "Script", color: "#00ff88", icon: "✍" },
  { id: "shot", name: "Shot", color: "#f59e0b", icon: "◉" },
  { id: "router", name: "Router", color: "#a855f7", icon: "⟳" },
  { id: "gemini", name: "Gemini", color: "#fbbc04", icon: "◈" },
  { id: "review", name: "Review", color: "#ff6b35", icon: "◑" },
  { id: "continuity", name: "Continuity", color: "#ec4899", icon: "∞" },
];

const VIEWS = ["chat", "canvas", "moodboard", "terminal", "trends", "agents", "projects"];

// ══════════════════════════════════════════════════════════
// SUBCOMPONENTS
// ══════════════════════════════════════════════════════════

// ── NODE CANVAS ───────────────────────────────────────────
function NodeCanvas({ nodes, connections, onAdd, onMove, selectedNode, onSelect }) {
  const [dragging, setDragging] = useState(null);
  const [offset, setOffset] = useState({ x: 0, y: 0 });
  const canvasRef = useRef();

  const nodeColor = (type) => ({ scene: "#00d4ff", agent: "#a855f7", model: "#f59e0b", asset: "#00ff88", idea: "#ff6b35" }[type] || "#555");

  const onMouseDown = (e, id) => { e.stopPropagation(); onSelect(id); setDragging(id); const r = e.currentTarget.getBoundingClientRect(); setOffset({ x: e.clientX - r.left, y: e.clientY - r.top }); };
  const onMouseMove = useCallback((e) => { if (!dragging || !canvasRef.current) return; const r = canvasRef.current.getBoundingClientRect(); onMove(dragging, { x: e.clientX - r.left - offset.x, y: e.clientY - r.top - offset.y }); }, [dragging, offset, onMove]);
  const onMouseUp = () => setDragging(null);

  return (
    <div ref={canvasRef} style={{ width: "100%", height: "100%", position: "relative", background: "#03030a", overflow: "hidden" }} onMouseMove={onMouseMove} onMouseUp={onMouseUp}>
      <svg style={{ position: "absolute", inset: 0, width: "100%", height: "100%", pointerEvents: "none" }}>
        <defs><pattern id="g" width="28" height="28" patternUnits="userSpaceOnUse"><path d="M 28 0 L 0 0 0 28" fill="none" stroke="#0d0d18" strokeWidth="1" /></pattern></defs>
        <rect width="100%" height="100%" fill="url(#g)" />
        {connections.map((c, i) => { const f = nodes.find(n => n.id === c.from); const t = nodes.find(n => n.id === c.to); if (!f || !t) return null; return <line key={i} x1={f.x + 70} y1={f.y + 20} x2={t.x} y2={t.y + 20} stroke={nodeColor(f.type) + "55"} strokeWidth={1.5} strokeDasharray={c.dashed ? "4 3" : "none"} />; })}
      </svg>
      {nodes.map(n => (
        <div key={n.id} onMouseDown={e => onMouseDown(e, n.id)} style={{ position: "absolute", left: n.x, top: n.y, minWidth: 130, background: "#0a0a14", border: `1px solid ${selectedNode === n.id ? nodeColor(n.type) : nodeColor(n.type) + "33"}`, borderRadius: 10, padding: "8px 12px", cursor: "grab", userSelect: "none", boxShadow: selectedNode === n.id ? `0 0 14px ${nodeColor(n.type)}44` : "none" }}>
          <div style={{ fontSize: 8, fontWeight: 700, letterSpacing: 1.5, color: nodeColor(n.type), textTransform: "uppercase", marginBottom: 3 }}>{n.type}</div>
          <div style={{ fontSize: 12, fontWeight: 600, color: "#e0e0f0" }}>{n.label}</div>
          {n.sub && <div style={{ fontSize: 10, color: "#555", marginTop: 2 }}>{n.sub}</div>}
          {n.model && <div style={{ marginTop: 5, fontSize: 9, padding: "2px 5px", background: nodeColor(n.type) + "22", borderRadius: 3, color: nodeColor(n.type), display: "inline-block" }}>{n.model}</div>}
        </div>
      ))}
      <button onClick={onAdd} style={{ position: "absolute", bottom: 14, right: 14, width: 34, height: 34, borderRadius: "50%", background: "#00d4ff1a", border: "1px solid #00d4ff33", color: "#00d4ff", fontSize: 18, cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center" }}>+</button>
    </div>
  );
}

// ── MOODBOARD ─────────────────────────────────────────────
function MoodBoard({ assets, onAdd, onRemove }) {
  const [dragOver, setDragOver] = useState(false);
  const [url, setUrl] = useState("");
  const fileRef = useRef();

  const PROPS = [
    { label: "Cinematic Dark", color: "#00d4ff", note: "Low key, film grain, contrast" },
    { label: "Street Energy", color: "#ff6b35", note: "Handheld, fast cuts, bass" },
    { label: "Afrofuturism", color: "#f9ca24", note: "Rich colors, cultural depth" },
    { label: "Lo-fi Warmth", color: "#ec4899", note: "VHS grain, nostalgia" },
    { label: "Clean Bold", color: "#00ff88", note: "Minimal, text-driven, pop" },
    { label: "Mudworld Dark", color: "#a855f7", note: "Out The Mud aesthetic" },
  ];

  return (
    <div style={{ height: "100%", display: "flex", flexDirection: "column", background: "#04040a", overflow: "hidden" }}>
      <div onDrop={e => { e.preventDefault(); setDragOver(false); Array.from(e.dataTransfer.files).forEach(f => onAdd({ id: Date.now() + Math.random(), type: "image", url: URL.createObjectURL(f), label: f.name })); }} onDragOver={e => { e.preventDefault(); setDragOver(true); }} onDragLeave={() => setDragOver(false)} onClick={() => fileRef.current?.click()} style={{ margin: 12, borderRadius: 10, border: `1px dashed ${dragOver ? "#00d4ff" : "#1a1a2a"}`, padding: "14px", textAlign: "center", cursor: "pointer", transition: "all 0.15s" }}>
        <input ref={fileRef} type="file" multiple accept="image/*,video/*" style={{ display: "none" }} onChange={e => Array.from(e.target.files).forEach(f => onAdd({ id: Date.now() + Math.random(), type: "image", url: URL.createObjectURL(f), label: f.name }))} />
        <div style={{ fontSize: 18, marginBottom: 3 }}>⊕</div>
        <div style={{ fontSize: 11, color: "#444" }}>Drop images & clips · or click to upload</div>
      </div>
      <div style={{ padding: "0 12px", display: "flex", gap: 6, marginBottom: 10 }}>
        <input value={url} onChange={e => setUrl(e.target.value)} placeholder="Paste reference URL..." onKeyDown={e => { if (e.key === "Enter" && url.trim()) { onAdd({ id: Date.now(), type: "ref", url, label: url }); setUrl(""); } }} style={{ flex: 1, background: "#0a0a14", border: "1px solid #1a1a2a", borderRadius: 6, color: "#c0c0d0", fontSize: 11, padding: "6px 8px", fontFamily: "inherit" }} />
        <button onClick={() => { if (url.trim()) { onAdd({ id: Date.now(), type: "ref", url, label: url }); setUrl(""); } }} style={{ background: "#00d4ff1a", border: "1px solid #00d4ff33", borderRadius: 6, color: "#00d4ff", fontSize: 11, padding: "0 10px", cursor: "pointer", fontFamily: "inherit" }}>Add</button>
      </div>
      <div style={{ padding: "0 12px", marginBottom: 10 }}>
        <div style={{ fontSize: 9, color: "#333", letterSpacing: 1.5, fontWeight: 700, textTransform: "uppercase", marginBottom: 6 }}>Visual Props</div>
        <div style={{ display: "flex", flexWrap: "wrap", gap: 5 }}>
          {PROPS.map(p => <button key={p.label} title={p.note} onClick={() => onAdd({ id: Date.now(), type: "prop", label: p.label, note: p.note, color: p.color })} style={{ fontSize: 10, padding: "3px 8px", borderRadius: 5, background: p.color + "11", border: `1px solid ${p.color}33`, color: p.color, cursor: "pointer", fontFamily: "inherit" }}>{p.label}</button>)}
        </div>
      </div>
      <div style={{ flex: 1, overflowY: "auto", padding: "0 12px 12px", display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8 }}>
        {assets.map(a => (
          <div key={a.id} style={{ background: "#0a0a14", border: "1px solid #1a1a2a", borderRadius: 8, overflow: "hidden", position: "relative" }}>
            {a.type === "image" && <img src={a.url} alt={a.label} style={{ width: "100%", height: 70, objectFit: "cover", display: "block" }} />}
            {a.type === "prop" && <div style={{ height: 70, background: a.color + "11", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 11, color: a.color, fontWeight: 600, textAlign: "center", padding: 8 }}>{a.label}<br /><span style={{ fontSize: 9, color: a.color + "99", fontWeight: 400 }}>{a.note}</span></div>}
            {a.type === "ref" && <div style={{ height: 70, background: "#0d0d1a", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 10, color: "#555", padding: 8, wordBreak: "break-all" }}>🔗 {a.label?.slice(0, 40)}</div>}
            <div style={{ padding: "4px 6px", display: "flex", justifyContent: "space-between", fontSize: 9, color: "#444" }}>
              <span style={{ overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap", maxWidth: 80 }}>{a.label}</span>
              <button onClick={() => onRemove(a.id)} style={{ background: "none", border: "none", color: "#333", cursor: "pointer", padding: 0 }}>✕</button>
            </div>
          </div>
        ))}
        {!assets.length && <div style={{ gridColumn: "1/-1", textAlign: "center", color: "#1a1a2a", fontSize: 12, paddingTop: 20 }}>Empty board · add refs, props, assets</div>}
      </div>
    </div>
  );
}

// ── CLI TERMINAL ───────────────────────────────────────────
function Terminal({ scenes, brain, projectName, onCommand }) {
  const [history, setHistory] = useState([
    { t: "sys", v: "Creator Factory CLI v2.0 — Agent One Runtime" },
    { t: "sys", v: "Commands: help | scenes | brain | models | export | trends | score | captions | variants | clear" },
  ]);
  const [input, setInput] = useState("");
  const [cmdHist, setCmdHist] = useState([]);
  const [histIdx, setHistIdx] = useState(-1);
  const ref = useRef();

  useEffect(() => { if (ref.current) ref.current.scrollTop = ref.current.scrollHeight; }, [history]);

  const log = (v, t = "out") => setHistory(h => [...h, { t, v }]);

  const run = async (cmd) => {
    const parts = cmd.trim().split(" ");
    const base = parts[0].toLowerCase();
    log(`$ ${cmd}`, "in");
    switch (base) {
      case "help": log(`status · scenes · scene [n] · brain · models · export json · export prompts · export capcut · export client · captions · variants [topic] · score [text] · trends [platform] · agents · clear`); break;
      case "status": log(`Project: ${projectName}\nScenes: ${scenes.length}\nBrain: ${Object.entries(brain).filter(([,v])=>v).map(([k])=>k).join(", ")||"empty"}`); break;
      case "scenes": scenes.length ? scenes.forEach((s, i) => log(`  [${i+1}] ${s.title||"Scene "+(i+1)} — ${s.model||"unrouted"} — ${s.generated?"✓ generated":"pending"}`)) : log("No scenes yet."); break;
      case "scene": { const s = scenes[parseInt(parts[1])-1]; s ? log(JSON.stringify(s, null, 2)) : log("Scene not found."); break; }
      case "brain": { const b = Object.entries(brain).filter(([,v])=>v); b.length ? b.forEach(([k,v]) => log(`[${k}]: ${v.slice(0,100)}...`)) : log("Brain empty."); break; }
      case "models": Object.entries(MODELS).forEach(([type, list]) => { log(`── ${type} ──`); list.forEach(m => log(`  ${m.id.padEnd(12)} ${m.name} ${m.live?"[LIVE]":""}`)); }); break;
      case "export": {
        if (parts[1] === "prompts") scenes.forEach((s, i) => log(`[S${i+1}] ${s.visualPrompt||"none"}`));
        else if (parts[1] === "capcut") log(buildCapcutExport(scenes));
        else if (parts[1] === "client") log(JSON.stringify(buildClientExport({ name: projectName, scenes }), null, 2));
        else log(JSON.stringify({ project: projectName, brain, scenes }, null, 2));
        break;
      }
      case "captions": { log("Generating captions...","sys"); const c = await generateCaptions(scenes); log(c); break; }
      case "variants": { const q = parts.slice(1).join(" ") || projectName; log(`Generating A/B variants for: "${q}"...`, "sys"); const v = await generateVariants(q, brain); log(JSON.stringify(v, null, 2)); break; }
      case "score": { const text = parts.slice(1).join(" "); if (!text) { log("Usage: score <hook text>"); break; } log("Scoring hook...", "sys"); const s = await scoreHook(text); log(JSON.stringify(s, null, 2)); break; }
      case "trends": { const p = parts[1] || "tiktok"; log(`Fetching ${p} trends via Gemini...`, "sys"); const t = await fetchTrends(p); log(JSON.stringify(t, null, 2)); break; }
      case "agents": AGENTS.forEach(a => log(`  ${a.icon} ${a.name}`)); break;
      case "clear": setHistory([]); break;
      default: log(`Unknown: ${base}. Type help.`);
    }
  };

  return (
    <div style={{ height: "100%", display: "flex", flexDirection: "column", background: "#03030a", fontFamily: "DM Mono, monospace" }}>
      <div ref={ref} style={{ flex: 1, overflowY: "auto", padding: "12px 16px", fontSize: 11, lineHeight: 1.8 }}>
        {history.map((h, i) => <div key={i} style={{ color: h.t === "sys" ? "#444" : h.t === "in" ? "#00ff88" : h.t === "err" ? "#ff4466" : "#c0c0d0", whiteSpace: "pre-wrap", wordBreak: "break-word" }}>{h.v}</div>)}
      </div>
      <div style={{ display: "flex", alignItems: "center", borderTop: "1px solid #0d0d18", padding: "8px 16px", gap: 8 }}>
        <span style={{ color: "#00ff88", fontSize: 12 }}>$</span>
        <input value={input} onChange={e => setInput(e.target.value)}
          onKeyDown={e => { if (e.key === "Enter" && input.trim()) { setCmdHist(h => [input, ...h]); setHistIdx(-1); run(input); setInput(""); } else if (e.key === "ArrowUp") { e.preventDefault(); const n = Math.min(histIdx+1, cmdHist.length-1); setHistIdx(n); setInput(cmdHist[n]||""); } else if (e.key === "ArrowDown") { e.preventDefault(); const n = Math.max(histIdx-1,-1); setHistIdx(n); setInput(n===-1?"":cmdHist[n]); } }}
          placeholder="command..." style={{ flex: 1, background: "transparent", border: "none", color: "#00ff88", fontSize: 11, fontFamily: "inherit" }} />
      </div>
    </div>
  );
}

// ══════════════════════════════════════════════════════════
// MAIN APP
// ══════════════════════════════════════════════════════════
export default function App() {
  const [view, setView] = useState("chat");
  const [mode, setMode] = useState("Director");
  const [input, setInput] = useState("");
  const [messages, setMessages] = useState([]);
  const [scenes, setScenes] = useState([]);
  const [selectedScene, setSelectedScene] = useState(null);
  const [agentSteps, setAgentSteps] = useState([]);
  const [isRunning, setIsRunning] = useState(false);
  const [generatingScene, setGeneratingScene] = useState(null);
  const [brain, setBrain] = useState({ rules: "", worldBuilding: "", characters: "", brand: "", knowledge: "" });
  const [activeSkill, setActiveSkill] = useState("shorts");
  const [assets, setAssets] = useState([]);
  const [projectName, setProjectName] = useState("New Project");
  const [projectId, setProjectId] = useState(null);
  const [projects, setProjects] = useState([]);
  const [alternatives, setAlternatives] = useState([]);
  const [credits, setCredits] = useState({ balance: 10 });
  const [trends, setTrends] = useState([]);
  const [loadingTrends, setLoadingTrends] = useState(false);
  const [voices, setVoices] = useState([]);
  const [selectedVoice, setSelectedVoice] = useState("21m00Tcm4TlvDq8ikWAM");
  const [abPanel, setAbPanel] = useState(null);
  const [hookPanel, setHookPanel] = useState(null);
  const [toast, setToast] = useState(null);
  const [nodes, setNodes] = useState([
    { id: "n1", type: "agent", label: "Director", sub: "Orchestrator", x: 40, y: 60 },
    { id: "n2", type: "agent", label: "Script", sub: "Narrative", x: 210, y: 20 },
    { id: "n3", type: "agent", label: "Shot", sub: "Visual", x: 210, y: 120 },
    { id: "n4", type: "agent", label: "Router", sub: "Models", x: 380, y: 60 },
    { id: "n5", type: "agent", label: "Review", sub: "QA", x: 550, y: 60 },
  ]);
  const nodeConnections = [{ from: "n1", to: "n2" }, { from: "n1", to: "n3" }, { from: "n2", to: "n4" }, { from: "n3", to: "n4" }, { from: "n4", to: "n5" }];
  const [selectedNode, setSelectedNode] = useState(null);
  const chatRef = useRef();
  const inputRef = useRef();

  useEffect(() => { if (chatRef.current) chatRef.current.scrollTop = chatRef.current.scrollHeight; }, [messages, agentSteps]);

  // Load on mount
  useEffect(() => {
    getCredits().then(setCredits);
    loadProjects().then(setProjects);
    getVoices().then(v => { if (v.length) setVoices(v); });
  }, []);

  const showToast = (msg, type = "info") => { setToast({ msg, type }); setTimeout(() => setToast(null), 3000); };

  const autosave = useCallback(async (updatedScenes, updatedBrain) => {
    const data = { id: projectId, name: projectName, brain: updatedBrain || brain, scenes: updatedScenes || scenes, assets, skill: activeSkill };
    const saved = await saveProject(data);
    if (saved?.id && !projectId) setProjectId(saved.id);
  }, [projectId, projectName, brain, scenes, assets, activeSkill]);

  const updateStep = (agentId, status, msg) => {
    setAgentSteps(prev => {
      const idx = prev.findIndex(s => s.agentId === agentId && s.status === "running");
      const entry = { agentId, status, msg };
      if (idx >= 0) { const u = [...prev]; u[idx] = entry; return u; }
      return [...prev, entry];
    });
  };

  const send = useCallback(async () => {
    if (!input.trim() || isRunning) return;
    const brief = input.trim();
    setInput("");
    setIsRunning(true);
    setAgentSteps([]);

    const userMsg = { role: "user", content: brief, type: "user" };
    setMessages(prev => [...prev, userMsg]);
    if (projectId) await saveMessage(projectId, { role: "user", content: brief, type: "user" });

    const isBrainstorm = /brainstorm|ideas?|suggest|alternatives?|what if|help me think/i.test(brief);
    const isAB = /a\/b|variant|test.*version|two version/i.test(brief);
    const isScore = /score.*hook|rate.*hook|how.*hook/i.test(brief);

    if (isBrainstorm) {
      const ideas = await runBrainstorm(brief, brain);
      const msg = { role: "assistant", content: ideas, type: "brainstorm" };
      setMessages(prev => [...prev, msg]);
      setIsRunning(false);
      return;
    }

    if (isAB) {
      showToast("Generating A/B variants...", "info");
      const variants = await generateVariants(brief, brain);
      setAbPanel(variants);
      setMessages(prev => [...prev, { role: "assistant", content: `A/B variants generated. Check the panel below.\n\nRecommendation: ${variants?.recommendation || ""}`, type: "ab" }]);
      setIsRunning(false);
      return;
    }

    try {
      const result = await runAgentPipeline(brief, brain, activeSkill, updateStep);
      if (result) {
        const newScenes = result.scenes || [];
        setScenes(newScenes);
        setSelectedScene(0);
        setAlternatives(result.alternatives || []);

        if (result.brainUpdate?.key && result.brainUpdate?.value) {
          setBrain(prev => ({ ...prev, [result.brainUpdate.key]: result.brainUpdate.value }));
        }
        if (projectName === "New Project" && result.title) setProjectName(result.title);

        // Add scene nodes to canvas
        setNodes(prev => {
          const sceneNodes = newScenes.slice(0, 6).map((s, i) => ({
            id: `sc_${i}`, type: "scene", label: s.title || `Scene ${i+1}`,
            sub: s.mood || "", model: s.model || "",
            x: 80 + (i % 3) * 190, y: 260 + Math.floor(i / 3) * 110,
          }));
          return [...prev.filter(n => !n.id.startsWith("sc_")), ...sceneNodes];
        });

        const summary = `Production ready — ${newScenes.length} scenes · Score: ${result.productionScore}/100 · Hook: ${result.hookScore}/100\n\n${result.reviewSummary}\n\n${result.geminiInsights ? `Gemini: ${result.geminiInsights}` : ""}`;
        const msg = { role: "assistant", content: summary, type: "plan", scenes: newScenes, alternatives: result.alternatives, brainstorm: result.brainstorm, hookRewrite: result.hookRewrite };
        setMessages(prev => [...prev, msg]);

        if (result.hookScore && result.hookScore < 70) {
          setHookPanel({ score: result.hookScore, rewrite: result.hookRewrite, verdict: result.hookVerdict });
        }

        await autosave(newScenes, brain);
        await deductCredits(0.5);
        getCredits().then(setCredits);
      }
    } catch (e) {
      setMessages(prev => [...prev, { role: "assistant", content: `Error: ${e.message}`, type: "error" }]);
    }
    setIsRunning(false);
  }, [input, isRunning, brain, activeSkill, projectName, projectId, autosave]);

  const handleKey = e => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); send(); } };

  // ── GENERATE SCENE ─────────────────────────────────────
  const handleGenerateScene = async (sceneIdx) => {
    const scene = scenes[sceneIdx];
    if (!scene || generatingScene !== null) return;
    setGeneratingScene(sceneIdx);
    showToast(`Generating Scene ${sceneIdx + 1} via ${scene.model || "Kling"}...`, "info");
    try {
      const genId = await trackGeneration(projectId, sceneIdx, scene.model, scene.visualPrompt);
      const result = await generateScene(scene, (msg) => showToast(msg, "info"));
      const updated = scenes.map((s, i) => i === sceneIdx ? { ...s, ...result, generated: true, status: "done" } : s);
      setScenes(updated);
      if (genId) await updateGeneration(genId, { status: "completed", result_url: result.videoUrl });
      await autosave(updated, brain);
      showToast(`Scene ${sceneIdx + 1} generated!`, "success");
    } catch (e) {
      showToast(`Generation failed: ${e.message}`, "error");
    }
    setGeneratingScene(null);
  };

  // ── LOAD TRENDS ────────────────────────────────────────
  const handleLoadTrends = async (platform = "tiktok") => {
    setLoadingTrends(true);
    const t = await fetchTrends(platform);
    setTrends(t);
    setLoadingTrends(false);
  };

  const moveNode = useCallback((id, pos) => setNodes(prev => prev.map(n => n.id === id ? { ...n, ...pos } : n)), []);
  const addNode = () => setNodes(prev => [...prev, { id: `node_${Date.now()}`, type: "idea", label: "New Node", sub: "drag to move", x: 160, y: 180 }]);

  // ── EXPORT HELPERS ─────────────────────────────────────
  const exportJSON = () => {
    const d = { project: projectName, brain, scenes, exported: new Date().toISOString() };
    const b = new Blob([JSON.stringify(d, null, 2)], { type: "application/json" });
    const a = document.createElement("a"); a.href = URL.createObjectURL(b); a.download = `${projectName.replace(/\s+/g,"_")}.json`; a.click();
  };
  const exportCapcut = () => {
    const b = new Blob([buildCapcutExport(scenes)], { type: "text/xml" });
    const a = document.createElement("a"); a.href = URL.createObjectURL(b); a.download = `${projectName.replace(/\s+/g,"_")}_capcut.xml`; a.click();
  };
  const exportClient = () => {
    const d = buildClientExport({ name: projectName, scenes });
    const b = new Blob([JSON.stringify(d, null, 2)], { type: "application/json" });
    const a = document.createElement("a"); a.href = URL.createObjectURL(b); a.download = `${projectName.replace(/\s+/g,"_")}_client.json`; a.click();
  };

  const agentColor = id => AGENTS.find(a => a.id === id)?.color || "#555";

  return (
    <div style={{ height: "100vh", background: "#050508", fontFamily: "'DM Mono','Fira Mono',monospace", color: "#e0e0f0", display: "flex", flexDirection: "column", overflow: "hidden" }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=DM+Mono:wght@300;400;500&family=Syne:wght@700;800&display=swap');
        *{box-sizing:border-box;margin:0;padding:0}
        ::-webkit-scrollbar{width:3px;height:3px}::-webkit-scrollbar-thumb{background:#1a1a2a;border-radius:2px}
        textarea,input{outline:none}
        @keyframes pulse{0%,100%{opacity:1}50%{opacity:.4}}
        @keyframes spin{from{transform:rotate(0)}to{transform:rotate(360deg)}}
        @keyframes up{from{opacity:0;transform:translateY(8px)}to{opacity:1;transform:translateY(0)}}
        @keyframes bounce{0%,80%,100%{transform:translateY(0)}40%{transform:translateY(-5px)}}
        .msg{animation:up .2s ease forwards}
        .btn:hover{opacity:.75!important}
        .nv:hover{background:#0d0d1a!important;color:#aaa!important}
      `}</style>

      {/* TOAST */}
      {toast && (
        <div style={{ position: "fixed", top: 56, right: 16, zIndex: 9999, padding: "10px 16px", borderRadius: 8, fontSize: 12, fontWeight: 600, background: toast.type === "error" ? "#ff446622" : toast.type === "success" ? "#00ff8822" : "#00d4ff22", border: `1px solid ${toast.type === "error" ? "#ff446644" : toast.type === "success" ? "#00ff8844" : "#00d4ff44"}`, color: toast.type === "error" ? "#ff4466" : toast.type === "success" ? "#00ff88" : "#00d4ff" }}>
          {toast.msg}
        </div>
      )}

      {/* TOPBAR */}
      <div style={{ height: 44, background: "#07070f", borderBottom: "1px solid #111118", display: "flex", alignItems: "center", padding: "0 14px", gap: 10, flexShrink: 0 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 7 }}>
          <div style={{ width: 26, height: 26, borderRadius: 7, background: "linear-gradient(135deg,#00d4ff,#a855f7,#ff6b35)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 11, fontWeight: 800, color: "#000" }}>CF</div>
          <span style={{ fontFamily: "Syne,sans-serif", fontWeight: 800, fontSize: 11, letterSpacing: 1.5 }}>CREATOR FACTORY</span>
          <span style={{ fontSize: 8, color: "#2a2a3a", letterSpacing: 1 }}>AGENT ONE</span>
        </div>
        <div style={{ width: 1, height: 14, background: "#1a1a2a" }} />
        <input value={projectName} onChange={e => setProjectName(e.target.value)} style={{ background: "transparent", border: "none", color: "#555", fontSize: 11, fontFamily: "inherit", maxWidth: 160 }} />
        <div style={{ flex: 1 }} />
        <div style={{ display: "flex", gap: 4, overflowX: "auto" }}>
          {CREATOR_SKILLS.slice(0, 5).map(s => (
            <button key={s.id} onClick={() => setActiveSkill(s.id)} className="btn" style={{ padding: "3px 9px", borderRadius: 4, fontSize: 9, fontWeight: 700, border: `1px solid ${activeSkill === s.id ? "#00d4ff44" : "#1a1a2a"}`, background: activeSkill === s.id ? "#00d4ff0f" : "transparent", color: activeSkill === s.id ? "#00d4ff" : "#444", cursor: "pointer", fontFamily: "inherit", whiteSpace: "nowrap" }}>{s.icon} {s.name}</button>
          ))}
        </div>
        <div style={{ display: "flex", background: "#0d0d1a", borderRadius: 6, border: "1px solid #1a1a2a", padding: 2 }}>
          {["Director", "Autopilot"].map(m => <button key={m} onClick={() => setMode(m)} className="btn" style={{ padding: "3px 9px", borderRadius: 4, fontSize: 9, fontWeight: 700, border: "none", background: mode === m ? "#00d4ff15" : "transparent", color: mode === m ? "#00d4ff" : "#444", cursor: "pointer", fontFamily: "inherit" }}>{m}</button>)}
        </div>
        <div style={{ display: "flex", gap: 4 }}>
          <span style={{ fontSize: 8, padding: "2px 6px", borderRadius: 3, background: "#00d4ff0f", border: "1px solid #00d4ff1a", color: "#00d4ff" }}>Claude</span>
          <span style={{ fontSize: 8, padding: "2px 6px", borderRadius: 3, background: "#fbbc040f", border: "1px solid #fbbc041a", color: "#fbbc04" }}>Gemini</span>
        </div>
        <span style={{ fontSize: 10, color: credits.balance > 2 ? "#00ff88" : "#ff4466", padding: "3px 8px", background: "#0a0a14", border: "1px solid #1a1a2a", borderRadius: 5 }}>
          {credits.balance?.toFixed(1)} cr
        </span>
      </div>

      {/* BODY */}
      <div style={{ flex: 1, display: "flex", overflow: "hidden" }}>

        {/* LEFT NAV */}
        <div style={{ width: 46, background: "#06060e", borderRight: "1px solid #111118", display: "flex", flexDirection: "column", alignItems: "center", paddingTop: 8, gap: 2, flexShrink: 0 }}>
          {[
            { id: "chat", icon: "◎", label: "Director" },
            { id: "canvas", icon: "⬡", label: "Canvas" },
            { id: "moodboard", icon: "◫", label: "Board" },
            { id: "terminal", icon: ">", label: "CLI" },
            { id: "trends", icon: "↑", label: "Trends" },
            { id: "agents", icon: "✦", label: "Agents" },
            { id: "projects", icon: "▤", label: "Projects" },
          ].map(n => (
            <button key={n.id} onClick={() => setView(n.id)} title={n.label} className="nv" style={{ width: 38, height: 38, borderRadius: 7, border: "none", background: view === n.id ? "#0d0d1a" : "transparent", color: view === n.id ? "#00d4ff" : "#2a2a3a", cursor: "pointer", fontSize: 13, fontFamily: "inherit", borderLeft: view === n.id ? "2px solid #00d4ff" : "2px solid transparent", transition: "all .15s", display: "flex", alignItems: "center", justifyContent: "center" }}>{n.icon}</button>
          ))}
        </div>

        {/* SCENE SIDEBAR */}
        {view === "chat" && (
          <div style={{ width: 196, background: "#06060e", borderRight: "1px solid #111118", display: "flex", flexDirection: "column", flexShrink: 0 }}>
            <div style={{ padding: "10px 12px 6px", fontSize: 8, fontWeight: 700, letterSpacing: 2, color: "#2a2a3a", textTransform: "uppercase" }}>Scenes · {scenes.length}</div>
            <div style={{ flex: 1, overflowY: "auto", padding: "0 8px 8px" }}>
              {scenes.map((s, i) => (
                <div key={i} onClick={() => setSelectedScene(i)} style={{ padding: "8px 10px", borderRadius: 8, marginBottom: 4, cursor: "pointer", background: selectedScene === i ? "#0d0d1a" : "transparent", border: `1px solid ${selectedScene === i ? "#00d4ff22" : "transparent"}`, transition: "all .15s" }}>
                  <div style={{ display: "flex", gap: 5, alignItems: "center", marginBottom: 3 }}>
                    <div style={{ width: 5, height: 5, borderRadius: "50%", background: s.generated ? "#00ff88" : s.model ? (MODELS.video.find(m => m.id === s.model)?.color || "#555") : "#2a2a3a" }} />
                    <span style={{ fontSize: 8, color: "#333", fontWeight: 700, letterSpacing: 1 }}>S{i+1}</span>
                    {s.model && <span style={{ fontSize: 8, color: "#444" }}>{s.model}</span>}
                    {s.generated && <span style={{ fontSize: 8, color: "#00ff88" }}>✓</span>}
                  </div>
                  <div style={{ fontSize: 11, color: "#777", lineHeight: 1.4 }}>{(s.title || `Scene ${i+1}`).slice(0, 30)}</div>
                  {!s.generated && (
                    <button onClick={e => { e.stopPropagation(); handleGenerateScene(i); }} disabled={generatingScene !== null} style={{ marginTop: 5, width: "100%", padding: "3px 0", borderRadius: 4, fontSize: 9, fontWeight: 700, background: generatingScene === i ? "#00d4ff22" : "#1a1a2a", border: `1px solid ${generatingScene === i ? "#00d4ff44" : "#2a2a3a"}`, color: generatingScene === i ? "#00d4ff" : "#444", cursor: "pointer", fontFamily: "inherit" }}>
                      {generatingScene === i ? "generating..." : "⚡ Generate"}
                    </button>
                  )}
                </div>
              ))}
              {!scenes.length && <div style={{ color: "#1a1a2a", fontSize: 11, padding: "14px 6px", textAlign: "center" }}>Brief the Director</div>}
            </div>
            {/* Agent steps */}
            <div style={{ borderTop: "1px solid #111118", padding: "8px 10px" }}>
              <div style={{ fontSize: 8, fontWeight: 700, letterSpacing: 2, color: "#222", marginBottom: 5, textTransform: "uppercase" }}>Crew</div>
              {agentSteps.slice(-4).map((s, i) => (
                <div key={i} style={{ display: "flex", alignItems: "center", gap: 5, marginBottom: 3 }}>
                  <div style={{ width: 4, height: 4, borderRadius: "50%", background: s.status === "running" ? agentColor(s.agentId) : s.status === "done" ? "#00ff88" : "#222", animation: s.status === "running" ? "pulse 1s infinite" : "none", flexShrink: 0 }} />
                  <span style={{ fontSize: 9, color: "#444", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{s.msg}</span>
                </div>
              ))}
              {!agentSteps.length && <div style={{ fontSize: 9, color: "#1a1a2a" }}>Idle</div>}
            </div>
          </div>
        )}

        {/* MAIN AREA */}
        <div style={{ flex: 1, display: "flex", flexDirection: "column", overflow: "hidden", minWidth: 0 }}>

          {/* CHAT */}
          {view === "chat" && (<>
            <div ref={chatRef} style={{ flex: 1, overflowY: "auto", padding: "18px 22px", display: "flex", flexDirection: "column", gap: 14 }}>
              {!messages.length && (
                <div style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 18, textAlign: "center", padding: 32 }}>
                  <div style={{ fontFamily: "Syne,sans-serif", fontWeight: 800, fontSize: 24, lineHeight: 1.2 }}>
                    <span style={{ color: "#00d4ff" }}>Director Agent</span><br />
                    <span style={{ color: "#222" }}>knows your world</span>
                  </div>
                  <div style={{ color: "#2a2a3a", fontSize: 12, lineHeight: 1.8, maxWidth: 340 }}>Mudworld · Creator Factory · Out The Mud · NBA Josh<br />Tell me what we're making.</div>
                  <div style={{ display: "flex", flexWrap: "wrap", gap: 7, justifyContent: "center", maxWidth: 480 }}>
                    {["YouTube Short — AI vs human creativity, Naija angle", "Brainstorm Creator Factory launch campaign angles", "Music video for my next NBA Josh drop", "NFT reveal for Mudworld collection drop", "Viral TikTok hook — Creator Factory waitlist sign up"].map((s, i) => (
                      <button key={i} onClick={() => setInput(s)} style={{ fontSize: 11, padding: "6px 11px", borderRadius: 7, background: "#0a0a14", border: "1px solid #1a1a2a", color: "#555", cursor: "pointer", fontFamily: "inherit", textAlign: "left", lineHeight: 1.4 }}>{s}</button>
                    ))}
                  </div>
                </div>
              )}

              {messages.map((msg, i) => (
                <div key={i} className="msg" style={{ display: "flex", justifyContent: msg.role === "user" ? "flex-end" : "flex-start", gap: 9 }}>
                  {msg.role !== "user" && (
                    <div style={{ width: 24, height: 24, borderRadius: 7, flexShrink: 0, marginTop: 3, background: "linear-gradient(135deg,#00d4ff1a,#a855f71a)", border: "1px solid #00d4ff22", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 10 }}>◎</div>
                  )}
                  <div style={{ maxWidth: "80%" }}>
                    <div style={{ background: msg.role === "user" ? "#0b1929" : "#090913", border: `1px solid ${msg.role === "user" ? "#00d4ff1a" : "#111118"}`, borderRadius: msg.role === "user" ? "13px 3px 13px 13px" : "3px 13px 13px 13px", padding: "11px 15px", fontSize: 13, lineHeight: 1.7, color: "#b0b0c0", whiteSpace: "pre-wrap" }}>
                      {msg.content}
                    </div>
                    {msg.alternatives?.length > 0 && (
                      <div style={{ marginTop: 8 }}>
                        <div style={{ fontSize: 8, color: "#333", letterSpacing: 1.5, fontWeight: 700, textTransform: "uppercase", marginBottom: 5 }}>Alternative Concepts</div>
                        <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
                          {msg.alternatives.map((alt, j) => (
                            <button key={j} onClick={() => setInput(`Let's go with: ${alt.title} — ${alt.concept}`)} style={{ fontSize: 11, padding: "6px 10px", borderRadius: 7, background: "#0a0a14", border: "1px solid #00d4ff1a", color: "#777", cursor: "pointer", fontFamily: "inherit", textAlign: "left", maxWidth: 180, lineHeight: 1.4 }}>
                              <div style={{ color: "#00d4ff", fontWeight: 600, fontSize: 11, marginBottom: 2 }}>{alt.title}</div>
                              <div style={{ fontSize: 10, color: "#444" }}>{alt.concept?.slice(0, 60)}</div>
                            </button>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              ))}

              {/* Hook warning panel */}
              {hookPanel && (
                <div style={{ background: "#140a00", border: "1px solid #ff6b3533", borderRadius: 10, padding: "12px 16px" }}>
                  <div style={{ fontSize: 10, fontWeight: 700, color: "#ff6b35", letterSpacing: 1, textTransform: "uppercase", marginBottom: 6 }}>⚠ Hook Score: {hookPanel.score}/100 — {hookPanel.verdict}</div>
                  <div style={{ fontSize: 12, color: "#888", marginBottom: 8 }}>Suggested rewrite:</div>
                  <div style={{ fontSize: 13, color: "#f59e0b", fontStyle: "italic", marginBottom: 8 }}>"{hookPanel.rewrite}"</div>
                  <div style={{ display: "flex", gap: 8 }}>
                    <button onClick={() => setInput(`Use this hook instead: "${hookPanel.rewrite}"`)} style={{ fontSize: 10, padding: "4px 10px", borderRadius: 5, background: "#ff6b3511", border: "1px solid #ff6b3533", color: "#ff6b35", cursor: "pointer", fontFamily: "inherit" }}>Use rewrite</button>
                    <button onClick={() => setHookPanel(null)} style={{ fontSize: 10, padding: "4px 10px", borderRadius: 5, background: "transparent", border: "1px solid #1a1a2a", color: "#444", cursor: "pointer", fontFamily: "inherit" }}>Dismiss</button>
                  </div>
                </div>
              )}

              {/* A/B panel */}
              {abPanel && (
                <div style={{ background: "#0a0a14", border: "1px solid #a855f733", borderRadius: 10, padding: "14px 16px" }}>
                  <div style={{ fontSize: 10, fontWeight: 700, color: "#a855f7", letterSpacing: 1, textTransform: "uppercase", marginBottom: 10 }}>A/B Variants</div>
                  <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, marginBottom: 10 }}>
                    {["variantA", "variantB"].map((k, i) => abPanel[k] && (
                      <div key={k} style={{ background: "#0d0d1a", border: "1px solid #1a1a2a", borderRadius: 8, padding: "10px 12px" }}>
                        <div style={{ fontSize: 9, fontWeight: 700, color: i === 0 ? "#00d4ff" : "#ff6b35", letterSpacing: 1, marginBottom: 5, textTransform: "uppercase" }}>Variant {i === 0 ? "A" : "B"} — {abPanel[k].tone}</div>
                        <div style={{ fontSize: 12, fontWeight: 600, color: "#c0c0d0", marginBottom: 4 }}>{abPanel[k].title}</div>
                        <div style={{ fontSize: 11, color: "#555", lineHeight: 1.5 }}>{abPanel[k].concept}</div>
                        <div style={{ marginTop: 6, fontSize: 10, color: "#888", fontStyle: "italic" }}>Hook: {abPanel[k].hook}</div>
                        <button onClick={() => { setInput(`Build variant ${i===0?"A":"B"}: ${abPanel[k].title} — ${abPanel[k].concept}`); setAbPanel(null); }} style={{ marginTop: 8, width: "100%", padding: "4px 0", borderRadius: 5, fontSize: 10, fontWeight: 700, background: i === 0 ? "#00d4ff11" : "#ff6b3511", border: `1px solid ${i === 0 ? "#00d4ff33" : "#ff6b3533"}`, color: i === 0 ? "#00d4ff" : "#ff6b35", cursor: "pointer", fontFamily: "inherit" }}>Build this →</button>
                      </div>
                    ))}
                  </div>
                  <div style={{ fontSize: 11, color: "#555", fontStyle: "italic" }}>{abPanel.recommendation}</div>
                </div>
              )}

              {isRunning && (
                <div className="msg" style={{ display: "flex", gap: 9 }}>
                  <div style={{ width: 24, height: 24, borderRadius: 7, flexShrink: 0, background: "linear-gradient(135deg,#00d4ff1a,#a855f71a)", border: "1px solid #00d4ff22", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 10, animation: "spin 2s linear infinite" }}>◎</div>
                  <div style={{ background: "#090913", border: "1px solid #111118", borderRadius: "3px 13px 13px 13px", padding: "12px 15px" }}>
                    <div style={{ display: "flex", flexDirection: "column", gap: 7 }}>
                      {AGENTS.filter(a => agentSteps.some(s => s.agentId === a.id)).map(a => {
                        const step = agentSteps.filter(s => s.agentId === a.id).slice(-1)[0];
                        return (
                          <div key={a.id} style={{ display: "flex", alignItems: "center", gap: 8 }}>
                            <div style={{ width: 5, height: 5, borderRadius: "50%", background: a.color, flexShrink: 0, animation: step?.status === "running" ? "pulse 1s infinite" : "none" }} />
                            <span style={{ fontSize: 10, color: a.color, fontWeight: 600, minWidth: 70 }}>{a.name}</span>
                            <span style={{ fontSize: 10, color: "#444" }}>{step?.msg}</span>
                            {step?.status === "done" && <span style={{ color: "#00ff88", fontSize: 10 }}>✓</span>}
                          </div>
                        );
                      })}
                      {!agentSteps.length && <div style={{ display: "flex", gap: 4 }}>{[0,1,2].map(i => <div key={i} style={{ width: 5, height: 5, borderRadius: "50%", background: "#00d4ff", animation: `bounce 1.2s ease-in-out ${i*.2}s infinite` }} />)}</div>}
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Scene strip */}
            {scenes[selectedScene] && (
              <div style={{ borderTop: "1px solid #111118", padding: "9px 20px", background: "#07070e", display: "flex", gap: 14, overflowX: "auto", flexShrink: 0 }}>
                {[
                  { l: "Scene", v: `${selectedScene+1} · ${scenes[selectedScene].title}` },
                  { l: "Shot", v: scenes[selectedScene].shot },
                  { l: "Model", v: scenes[selectedScene].model, c: MODELS.video.find(m=>m.id===scenes[selectedScene].model)?.color },
                  { l: "VO", v: scenes[selectedScene].vo || scenes[selectedScene].voiceover, i: true },
                  { l: "Prompt", v: scenes[selectedScene].visualPrompt, c: "#a855f7" },
                ].filter(f=>f.v).map((f,i) => (
                  <div key={i} style={{ flexShrink: 0, maxWidth: 170 }}>
                    <div style={{ fontSize: 7, fontWeight: 700, letterSpacing: 2, color: "#2a2a3a", textTransform: "uppercase", marginBottom: 2 }}>{f.l}</div>
                    <div style={{ fontSize: 10, color: f.c || "#666", fontStyle: f.i ? "italic" : "normal", lineHeight: 1.5 }}>{f.v?.toString().slice(0,90)}</div>
                  </div>
                ))}
                {scenes[selectedScene].videoUrl && <div style={{ flexShrink: 0 }}><div style={{ fontSize: 7, fontWeight: 700, letterSpacing: 2, color: "#2a2a3a", textTransform: "uppercase", marginBottom: 2 }}>Preview</div><a href={scenes[selectedScene].videoUrl} target="_blank" rel="noreferrer" style={{ fontSize: 10, color: "#00ff88" }}>▶ Play</a></div>}
              </div>
            )}

            {/* Input */}
            <div style={{ padding: "10px 14px", background: "#07070f", borderTop: "1px solid #111118", flexShrink: 0 }}>
              <div style={{ background: "#0a0a14", border: "1px solid #1a1a2a", borderRadius: 11, padding: "9px 13px" }}>
                <textarea ref={inputRef} value={input} onChange={e => setInput(e.target.value)} onKeyDown={handleKey} placeholder={`Brief the Director · skill: ${CREATOR_SKILLS.find(s=>s.id===activeSkill)?.name} · Try: "brainstorm", "a/b", or a full brief...`} rows={2} style={{ background: "transparent", border: "none", color: "#e0e0f0", fontSize: 13, fontFamily: "inherit", resize: "none", lineHeight: 1.6, width: "100%" }} />
                <div style={{ display: "flex", alignItems: "center", gap: 7, marginTop: 5 }}>
                  <span style={{ fontSize: 8, padding: "2px 6px", borderRadius: 3, background: "#00d4ff0f", border: "1px solid #00d4ff1a", color: "#00d4ff" }}>{CREATOR_SKILLS.find(s=>s.id===activeSkill)?.icon} {CREATOR_SKILLS.find(s=>s.id===activeSkill)?.name}</span>
                  <span style={{ fontSize: 8, color: "#2a2a3a" }}>{mode}</span>
                  <div style={{ flex: 1 }} />
                  <button onClick={exportJSON} className="btn" style={{ fontSize: 9, padding: "3px 8px", borderRadius: 4, background: "transparent", border: "1px solid #1a1a2a", color: "#444", cursor: "pointer", fontFamily: "inherit" }}>↓ JSON</button>
                  <button onClick={exportCapcut} className="btn" style={{ fontSize: 9, padding: "3px 8px", borderRadius: 4, background: "transparent", border: "1px solid #1a1a2a", color: "#444", cursor: "pointer", fontFamily: "inherit" }}>↓ CapCut</button>
                  <button onClick={exportClient} className="btn" style={{ fontSize: 9, padding: "3px 8px", borderRadius: 4, background: "transparent", border: "1px solid #1a1a2a", color: "#444", cursor: "pointer", fontFamily: "inherit" }}>↓ Client</button>
                  <button onClick={send} disabled={isRunning || !input.trim()} style={{ padding: "5px 14px", borderRadius: 7, fontSize: 11, fontWeight: 700, background: isRunning || !input.trim() ? "#1a1a2a" : "#00d4ff", border: "none", color: isRunning || !input.trim() ? "#333" : "#000", cursor: isRunning || !input.trim() ? "not-allowed" : "pointer", fontFamily: "inherit" }}>{isRunning ? "Running..." : "Send"}</button>
                </div>
              </div>
            </div>
          </>)}

          {/* CANVAS */}
          {view === "canvas" && <NodeCanvas nodes={nodes} connections={nodeConnections} onAdd={addNode} onMove={moveNode} selectedNode={selectedNode} onSelect={setSelectedNode} />}

          {/* MOODBOARD */}
          {view === "moodboard" && <MoodBoard assets={assets} onAdd={a => setAssets(prev => [...prev, a])} onRemove={id => setAssets(prev => prev.filter(a => a.id !== id))} />}

          {/* TERMINAL */}
          {view === "terminal" && <Terminal scenes={scenes} brain={brain} projectName={projectName} />}

          {/* TRENDS */}
          {view === "trends" && (
            <div style={{ padding: 22, overflowY: "auto" }}>
              <div style={{ fontFamily: "Syne,sans-serif", fontWeight: 800, fontSize: 17, marginBottom: 4 }}>Trend Intelligence</div>
              <div style={{ fontSize: 11, color: "#444", marginBottom: 20 }}>Powered by Gemini — real-time viral content analysis</div>
              <div style={{ display: "flex", gap: 8, marginBottom: 20 }}>
                {["tiktok", "youtube", "instagram", "twitter"].map(p => (
                  <button key={p} onClick={() => handleLoadTrends(p)} disabled={loadingTrends} style={{ padding: "6px 14px", borderRadius: 7, fontSize: 11, fontWeight: 600, background: "#0a0a14", border: "1px solid #1a1a2a", color: "#777", cursor: "pointer", fontFamily: "inherit" }}>{p}</button>
                ))}
                {loadingTrends && <span style={{ fontSize: 11, color: "#444", alignSelf: "center" }}>Fetching via Gemini...</span>}
              </div>
              {!trends.length && !loadingTrends && <div style={{ color: "#1a1a2a", fontSize: 13, textAlign: "center", paddingTop: 40 }}>Select a platform to fetch trends</div>}
              <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
                {trends.map((t, i) => (
                  <div key={i} style={{ background: "#0a0a14", border: "1px solid #1a1a2a", borderRadius: 10, padding: "14px 16px" }}>
                    <div style={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between", marginBottom: 8 }}>
                      <div style={{ fontSize: 13, fontWeight: 600, color: "#e0e0f0" }}>{t.title}</div>
                      <span style={{ fontSize: 10, color: "#00ff88", padding: "2px 7px", background: "#00ff8811", borderRadius: 4, whiteSpace: "nowrap", marginLeft: 8 }}>{t.reach}</span>
                    </div>
                    <div style={{ fontSize: 11, color: "#555", marginBottom: 6, fontStyle: "italic" }}>Hook: {t.hook}</div>
                    <div style={{ fontSize: 11, color: "#444", marginBottom: 10 }}>{t.why}</div>
                    <div style={{ fontSize: 11, color: "#00d4ff", marginBottom: 10 }}>Your angle: {t.idea}</div>
                    <button onClick={() => { setInput(t.idea); setView("chat"); }} style={{ fontSize: 10, padding: "4px 10px", borderRadius: 5, background: "#00d4ff11", border: "1px solid #00d4ff22", color: "#00d4ff", cursor: "pointer", fontFamily: "inherit" }}>Build this →</button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* AGENTS */}
          {view === "agents" && (
            <div style={{ padding: 22, overflowY: "auto" }}>
              <div style={{ fontFamily: "Syne,sans-serif", fontWeight: 800, fontSize: 17, marginBottom: 20 }}>Agent Crew & Models</div>
              <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill,minmax(240px,1fr))", gap: 10, marginBottom: 28 }}>
                {AGENTS.map(a => {
                  const step = agentSteps.filter(s => s.agentId === a.id).slice(-1)[0];
                  return (
                    <div key={a.id} style={{ background: "#0a0a14", border: `1px solid ${step?.status === "running" ? a.color + "44" : "#1a1a2a"}`, borderRadius: 11, padding: "14px 16px", boxShadow: step?.status === "running" ? `0 0 18px ${a.color}22` : "none", transition: "all .3s" }}>
                      <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 8 }}>
                        <div style={{ width: 34, height: 34, borderRadius: 9, background: a.color + "11", border: `1px solid ${a.color}33`, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 15, color: a.color }}>{a.icon}</div>
                        <div><div style={{ fontSize: 12, fontWeight: 600, color: "#e0e0f0" }}>{a.name}</div><div style={{ fontSize: 9, color: "#555" }}>{a.id}</div></div>
                      </div>
                      <div style={{ display: "flex", alignItems: "center", gap: 5 }}>
                        <div style={{ width: 5, height: 5, borderRadius: "50%", background: step?.status === "running" ? a.color : step?.status === "done" ? "#00ff88" : "#1a1a2a", animation: step?.status === "running" ? "pulse 1s infinite" : "none" }} />
                        <span style={{ fontSize: 10, color: "#444" }}>{step?.msg || "Idle"}</span>
                      </div>
                    </div>
                  );
                })}
              </div>
              {Object.entries(MODELS).map(([type, list]) => (
                <div key={type} style={{ marginBottom: 20 }}>
                  <div style={{ fontSize: 8, fontWeight: 700, letterSpacing: 2, color: "#333", textTransform: "uppercase", marginBottom: 8 }}>{type} models</div>
                  <div style={{ display: "flex", flexWrap: "wrap", gap: 6 }}>
                    {list.map(m => (
                      <div key={m.id} style={{ padding: "5px 11px", borderRadius: 7, background: m.color + "0f", border: `1px solid ${m.color}22`, fontSize: 11 }}>
                        <span style={{ color: m.color, fontWeight: 600 }}>{m.name}</span>
                        {m.live && <span style={{ marginLeft: 5, fontSize: 8, color: "#00ff88", fontWeight: 700 }}>LIVE</span>}
                        <span style={{ color: "#333", marginLeft: 6, fontSize: 9 }}>{m.best}</span>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* PROJECTS */}
          {view === "projects" && (
            <div style={{ padding: 22, overflowY: "auto" }}>
              <div style={{ fontFamily: "Syne,sans-serif", fontWeight: 800, fontSize: 17, marginBottom: 4 }}>Projects</div>
              <div style={{ fontSize: 11, color: "#444", marginBottom: 20 }}>Saved to Supabase · auto-synced</div>
              <button onClick={() => { setScenes([]); setMessages([]); setAgentSteps([]); setProjectName("New Project"); setProjectId(null); setView("chat"); }} style={{ marginBottom: 16, padding: "7px 14px", borderRadius: 7, fontSize: 11, fontWeight: 700, background: "#00d4ff11", border: "1px solid #00d4ff22", color: "#00d4ff", cursor: "pointer", fontFamily: "inherit" }}>+ New Project</button>
              <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
                {projects.map(p => (
                  <div key={p.id} onClick={async () => { const full = await loadProject(p.id); if (full) { setProjectId(full.id); setProjectName(full.name); setBrain(full.brain || {}); setScenes(full.scenes || []); setAssets(full.assets || []); setView("chat"); const msgs = await loadMessages(full.id); setMessages(msgs); } }} style={{ background: "#0a0a14", border: "1px solid #1a1a2a", borderRadius: 10, padding: "12px 16px", cursor: "pointer", transition: "border-color .15s" }}>
                    <div style={{ fontSize: 13, fontWeight: 600, color: "#c0c0d0", marginBottom: 4 }}>{p.name}</div>
                    <div style={{ fontSize: 10, color: "#444" }}>{p.scenes?.length || 0} scenes · score {p.production_score || 0} · {new Date(p.updated_at).toLocaleDateString()}</div>
                  </div>
                ))}
                {!projects.length && <div style={{ color: "#1a1a2a", fontSize: 12, textAlign: "center", paddingTop: 30 }}>No saved projects yet.<br />Configure Supabase in .env.local</div>}
              </div>
            </div>
          )}
        </div>

        {/* RIGHT: BRAIN PANEL */}
        {view === "chat" && (
          <div style={{ width: 210, background: "#06060e", borderLeft: "1px solid #111118", display: "flex", flexDirection: "column", flexShrink: 0 }}>
            <div style={{ padding: "10px 12px 6px", fontSize: 8, fontWeight: 700, letterSpacing: 2, color: "#2a2a3a", textTransform: "uppercase" }}>Agent Brain</div>
            <div style={{ flex: 1, overflowY: "auto", padding: "0 10px" }}>
              {[
                { k: "rules", l: "Rules", c: "#ffaa00" },
                { k: "worldBuilding", l: "World", c: "#00d4ff" },
                { k: "characters", l: "Characters", c: "#a855f7" },
                { k: "brand", l: "Brand", c: "#00ff88" },
                { k: "knowledge", l: "Knowledge", c: "#ff6b35" },
              ].map(f => (
                <div key={f.k} style={{ marginBottom: 11 }}>
                  <div style={{ fontSize: 7, fontWeight: 700, letterSpacing: 1.5, color: f.c, textTransform: "uppercase", marginBottom: 3 }}>{f.l}</div>
                  <textarea value={brain[f.k]} onChange={e => setBrain(prev => ({ ...prev, [f.k]: e.target.value }))} placeholder={`+ ${f.l.toLowerCase()}...`} rows={2} style={{ width: "100%", background: "#0a0a14", border: "1px solid #1a1a2a", borderRadius: 5, color: "#777", fontSize: 10, padding: "5px 7px", fontFamily: "inherit", resize: "none", lineHeight: 1.5 }} />
                </div>
              ))}
              {/* Voice selector */}
              {voices.length > 0 && (
                <div style={{ marginBottom: 11 }}>
                  <div style={{ fontSize: 7, fontWeight: 700, letterSpacing: 1.5, color: "#00d4ff", textTransform: "uppercase", marginBottom: 3 }}>EL Voice</div>
                  <select value={selectedVoice} onChange={e => setSelectedVoice(e.target.value)} style={{ width: "100%", background: "#0a0a14", border: "1px solid #1a1a2a", borderRadius: 5, color: "#777", fontSize: 10, padding: "5px 7px", fontFamily: "inherit" }}>
                    {voices.map(v => <option key={v.voice_id} value={v.voice_id}>{v.name}</option>)}
                  </select>
                </div>
              )}
            </div>
            <div style={{ padding: 10, borderTop: "1px solid #111118", display: "flex", flexDirection: "column", gap: 5 }}>
              <button onClick={async () => { await autosave(); showToast("Saved!", "success"); }} style={{ width: "100%", padding: "6px 0", borderRadius: 6, fontSize: 10, fontWeight: 700, background: "#00ff8811", border: "1px solid #00ff8822", color: "#00ff88", cursor: "pointer", fontFamily: "inherit" }}>↑ Save Project</button>
              <button onClick={exportJSON} style={{ width: "100%", padding: "6px 0", borderRadius: 6, fontSize: 10, fontWeight: 700, background: "#00d4ff11", border: "1px solid #00d4ff22", color: "#00d4ff", cursor: "pointer", fontFamily: "inherit" }}>↓ Export JSON</button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
