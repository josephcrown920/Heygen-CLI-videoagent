# Creator Factory — Agent One Platform
### Full AI Video Production System

Built for: NBA Josh / Out The Mud Records / Creator Factory

---

## What's in here

```
src/
  App.js              — Full UI (7 views, all features)
  lib/
    intelligence.js   — Claude + Gemini dual intelligence, all agents
    generation.js     — fal.ai (Kling/Flux/Seedance) + ElevenLabs
    db.js             — Supabase persistence layer
supabase/
  schema.sql          — Run this in your Supabase project
.env.example          — Copy to .env.local and fill in keys
```

---

## Features

### Intelligence
- Claude Sonnet 4 — Director, Script, Shot, Router, Review, Continuity agents
- Gemini Flash — trend research, platform optimization insights
- 7-stage multi-agent pipeline, all wired and running

### Generation (LIVE via fal.ai)
- Kling 3.0 — action/realism video
- Seedance 2.0 — style/aesthetic video  
- FLUX Pro 1.1 — stills and thumbnails
- ElevenLabs v3 — voiceover with voice library

### UI Views
1. Director Chat — brief → full production plan, A/B variants, hook scoring, brainstorm mode
2. Node Canvas — draggable agent/scene graph
3. Moodboard — drag-drop refs, visual props, style presets
4. CLI Terminal — full command line (scenes, brain, export, trends, score, captions)
5. Trend Intelligence — Gemini-powered viral trend fetch per platform
6. Agents Panel — crew status + creator skills + all models
7. Projects — Supabase-saved projects, full history

### Creator Skills
YouTube Shorts · TikTok Viral · Music Video · Performance Ad · Cinematic Short · UGC/Avatar · NFT Drop Reveal · Product Launch

### Exports
- Production JSON (full plan)
- CapCut XML sequence
- Client-ready JSON (shareable)
- SRT captions (via CLI: `captions`)

---

## Setup

### 1. Install & run

```bash
npm install
cp .env.example .env.local
# Fill in your keys in .env.local
npm start
```

### 2. Supabase (for persistence)
1. Create project at supabase.com
2. Go to SQL Editor
3. Paste and run contents of `supabase/schema.sql`
4. Copy your project URL and anon key to `.env.local`

### 3. Get your API keys

| Key | Where to get |
|-----|-------------|
| ANTHROPIC_KEY | console.anthropic.com |
| GEMINI_KEY | aistudio.google.com |
| FAL_KEY | fal.ai/dashboard (covers Kling + Flux + Seedance) |
| ELEVENLABS_KEY | elevenlabs.io |
| SUPABASE_URL | supabase.com → your project → settings |
| SUPABASE_ANON_KEY | supabase.com → your project → settings |
| PAYSTACK_PUBLIC_KEY | dashboard.paystack.com |

### 4. Replit deployment
1. Upload zip or push to GitHub and import to Replit
2. Set all env vars in Replit Secrets (not .env.local — use Secrets tab)
3. Run `npm start` or `npm run build` for production

---

## CLI Commands (in Terminal view)

```
status              — project overview
scenes              — list all scenes
scene [n]           — inspect scene N in detail
brain               — show brain memory
models              — all models with LIVE status
export json         — full production JSON
export prompts      — all visual gen prompts
export capcut       — CapCut XML sequence
export client       — shareable client JSON
captions            — generate SRT captions
variants [topic]    — A/B variant generation
score [hook text]   — score a hook 0-100
trends [platform]   — fetch viral trends via Gemini
agents              — list agent crew
clear               — clear terminal
```

---

## Notes

- Kling and Seedance run via fal.ai queue — generation takes 60-180 seconds
- ElevenLabs VO generates immediately
- Without Supabase keys, the app still works fully — just no persistence
- Without fal.ai key, the Generate buttons will error (the planning pipeline still works)
- Brain memory persists in state per session; Supabase makes it permanent

---

## Architecture

```
Brief → Director Agent (Claude)
      → Script Agent (Claude)  
      → Shot Agent (Claude)
      → Gemini Research
      → Model Router (Claude)
      → Review Agent (Claude)
      → Continuity + Hook Score
      → Production Plan + Scenes
         → Generate button → fal.ai (Kling/Seedance)
         → VO button → ElevenLabs
         → Thumb → FLUX
```

---

Built by Claude for Out The Mud Records / Creator Factory
