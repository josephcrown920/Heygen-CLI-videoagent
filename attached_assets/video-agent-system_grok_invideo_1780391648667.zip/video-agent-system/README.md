# Your Personal Video Agent System (May 2026)

**One command to rule them all.**

## Quick Start

1. Install Docker + NVIDIA Toolkit on your machine/VPS:
   ```bash
   sudo apt update && sudo apt install docker.io docker-compose-plugin nvidia-container-toolkit -y
   sudo systemctl enable --now docker
   ```

2. Extract this zip.

3. Edit `.env` file (change passwords + put your real xAI API key from https://console.x.ai).

4. Start the system:
   ```bash
   docker compose up -d
   ```

5. Watch real-time logs in terminal:
   ```bash
   docker compose logs -f
   ```

## Access
- Chatbot: http://YOUR-IP:8080
- n8n: http://YOUR-IP:5678 (admin / password from .env)
- ComfyUI: http://YOUR-IP:8188

## Next
- In n8n install ComfyUI community node and import the workflow.
- Add LTX 2.3 models in ComfyUI.

Your own full video agent with chatbot, memory, and automation. Enjoy!
