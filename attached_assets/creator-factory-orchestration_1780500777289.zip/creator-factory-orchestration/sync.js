// ============================================================
// SYNC.SO ROUTE — Lip Sync API
// Syncs audio to video for AI avatar / talking head content
// Used in your NBA Josh / Creator Factory video pipeline
// ============================================================

const PROVIDERS = {
  syncso: {
    models: {
      'sync-1.9.0-beta': 'sync-1.9.0-beta', // latest
      'sync-1.8.0':      'sync-1.8.0',
      'wav2lip':         'wav2lip++',
    },
    defaultModel: 'sync-1.9.0-beta',
    baseURL: 'https://api.sync.so/v2',
    envKey: 'SYNCSO_API_KEY',
    creditsPerMinute: 500,
  },
  // Fallback: Replicate wav2lip
  replicate: {
    models: {
      'wav2lip':   'cjwbw/wav2lip:8d65e3f4f4298520e079198b493c25adfc43c058ffec9f19bf8a89849a0374b5',
      'sadtalker': 'cjwbw/sadtalker:a6ea89def8d2125215e4d2f920d608b171a7a444e8f8e2b635f432e7a8afc35c',
    },
    defaultModel: 'wav2lip',
    baseURL: 'https://api.replicate.com/v1',
    envKey: 'REPLICATE_API_TOKEN',
    creditsPerMinute: 300,
  },
};

function resolveProvider(modelString) {
  if (!modelString) return { provider: 'syncso', modelKey: 'sync-1.9.0-beta' };
  if (modelString.includes('/')) {
    const [provider, model] = modelString.split('/');
    return { provider, modelKey: model };
  }
  for (const [provider, config] of Object.entries(PROVIDERS)) {
    if (config.models[modelString]) return { provider, modelKey: modelString };
  }
  return { provider: 'syncso', modelKey: 'sync-1.9.0-beta' };
}

// ── Sync.so ───────────────────────────────────────────────
async function callSyncSo(videoUrl, audioUrl, modelKey, options = {}) {
  const config = PROVIDERS.syncso;
  const model = config.models[modelKey] || config.models[config.defaultModel];

  // Submit lipsync job
  const submitRes = await fetch(`${config.baseURL}/generate`, {
    method: 'POST',
    headers: {
      'x-api-key': process.env[config.envKey],
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      model,
      input: [
        { type: 'video', url: videoUrl },
        { type: 'audio', url: audioUrl },
      ],
      options: {
        pads: options.pads || [0, 5, 0, 0],
        resize_factor: options.resizeFactor || 1,
        smooth: options.smooth ?? true,
        fps: options.fps || 25,
      },
      webhookUrl: options.webhookUrl || null,
    }),
  });

  if (!submitRes.ok) throw new Error(`Sync.so submit error: ${submitRes.status} ${await submitRes.text()}`);
  const { id } = await submitRes.json();

  console.log(`⏳ Sync.so job queued: ${id}`);

  // Poll for result (max 5 minutes for long videos)
  let attempts = 0;
  const maxAttempts = 150; // 150 × 2s = 5min

  while (attempts < maxAttempts) {
    await new Promise(r => setTimeout(r, 2000));

    const pollRes = await fetch(`${config.baseURL}/generate/${id}`, {
      headers: { 'x-api-key': process.env[config.envKey] },
    });

    if (!pollRes.ok) throw new Error(`Sync.so poll error: ${pollRes.status}`);
    const status = await pollRes.json();

    if (status.status === 'completed') {
      const outputUrl = status.outputUrl || status.output?.url;
      const durationSec = status.input?.duration || options.estimatedDuration || 10;

      return {
        output: outputUrl,
        provider: 'syncso',
        model,
        creditsUsed: Math.ceil(config.creditsPerMinute * (durationSec / 60)),
        metadata: {
          jobId: id,
          duration: durationSec,
          syncScore: status.syncScore,
        },
      };
    }

    if (status.status === 'failed') {
      throw new Error(`Sync.so job failed: ${status.error || 'Unknown error'}`);
    }

    console.log(`⏳ Sync.so status: ${status.status} (${attempts * 2}s elapsed)`);
    attempts++;
  }

  throw new Error('Sync.so timed out after 5 minutes');
}

// ── Replicate Wav2Lip (fallback) ──────────────────────────
async function callReplicateLipSync(videoUrl, audioUrl, modelKey, options = {}) {
  const config = PROVIDERS.replicate;
  const modelVersion = config.models[modelKey] || config.models[config.defaultModel];

  const startRes = await fetch(`${config.baseURL}/predictions`, {
    method: 'POST',
    headers: {
      'Authorization': `Token ${process.env[config.envKey]}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      version: modelVersion.split(':')[1],
      input: {
        face: videoUrl,
        audio: audioUrl,
        fps: options.fps || 25,
        pads: options.pads || '0 10 0 0',
        smooth: options.smooth ?? true,
        resize_factor: options.resizeFactor || 1,
      },
    }),
  });

  if (!startRes.ok) throw new Error(`Replicate lipsync start error: ${startRes.status}`);
  let prediction = await startRes.json();

  let attempts = 0;
  while (['starting', 'processing'].includes(prediction.status) && attempts < 90) {
    await new Promise(r => setTimeout(r, 2000));
    const pollRes = await fetch(`${config.baseURL}/predictions/${prediction.id}`, {
      headers: { 'Authorization': `Token ${process.env[config.envKey]}` },
    });
    prediction = await pollRes.json();
    attempts++;
  }

  if (prediction.status !== 'succeeded') {
    throw new Error(`Replicate lipsync failed: ${prediction.error}`);
  }

  return {
    output: prediction.output,
    provider: 'replicate',
    model: modelKey,
    creditsUsed: config.creditsPerMinute,
    metadata: { predictionId: prediction.id },
  };
}

const CALLERS = { syncso: callSyncSo, replicate: callReplicateLipSync };
const FALLBACK_CHAIN = ['syncso', 'replicate'];

// ── Main export ───────────────────────────────────────────
// Called via POST /api/sync
// Body: { videoUrl, audioUrl, model, options, userEmail }
export async function syncLipsync({ videoUrl, audioUrl, model, options = {} }) {
  if (!videoUrl || !audioUrl) {
    throw new Error('Both videoUrl and audioUrl are required for lip sync');
  }

  const { provider: preferredProvider, modelKey } = resolveProvider(model);
  const chain = [preferredProvider, ...FALLBACK_CHAIN.filter(p => p !== preferredProvider)];
  const errors = [];

  for (const provider of chain) {
    const apiKey = process.env[PROVIDERS[provider]?.envKey];
    if (!apiKey) { errors.push(`${provider}: no API key`); continue; }
    try {
      console.log(`👄 Lip sync via ${provider} [${modelKey}]...`);
      const result = await CALLERS[provider](videoUrl, audioUrl, modelKey, options);
      console.log(`✅ Lip sync success via ${provider}`);
      return result;
    } catch (err) {
      console.warn(`⚠️ ${provider} failed: ${err.message}`);
      errors.push(`${provider}: ${err.message}`);
    }
  }

  throw new Error(`All lipsync providers failed:\n${errors.join('\n')}`);
}
