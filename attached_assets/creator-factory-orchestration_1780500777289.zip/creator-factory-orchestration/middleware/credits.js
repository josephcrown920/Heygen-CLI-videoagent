// middleware/credits.js
// ============================================================
// CREDIT MIDDLEWARE — checks balance before generation
// ============================================================
import { supabase } from '../server.js';

const MIN_CREDITS_REQUIRED = {
  text:  1,
  image: 40,
  video: 200,
  audio: 50,
};

export async function checkCredits(req, res, next) {
  const { userEmail, type } = req.body;
  
  // No email = guest/free mode, skip credit check
  if (!userEmail) return next();
  
  try {
    const { data: user } = await supabase
      .from('users')
      .select('total_credits')
      .eq('email', userEmail)
      .single();
    
    if (!user) {
      return res.status(404).json({ error: 'User not found. Please purchase credits first.' });
    }
    
    const minRequired = MIN_CREDITS_REQUIRED[type] || 1;
    if (user.total_credits < minRequired) {
      return res.status(402).json({
        error: 'Insufficient credits',
        currentCredits: user.total_credits,
        requiredCredits: minRequired,
        type,
        message: 'Purchase more credits at creatorfactory.io/credits'
      });
    }
    
    req.userCredits = user.total_credits;
    next();
  } catch (err) {
    // Don't block generation on credit check failure
    console.warn('Credit check failed:', err.message);
    next();
  }
}

export async function deductCredits(email, amount, reason = 'AI generation') {
  try {
    const { data: user } = await supabase
      .from('users')
      .select('id, total_credits')
      .eq('email', email)
      .single();
    
    if (!user) return;
    
    const newBalance = Math.max(0, user.total_credits - amount);
    
    await supabase.from('users').update({ total_credits: newBalance }).eq('id', user.id);
    
    await supabase.from('credit_transactions').insert([{
      user_id: user.id,
      amount,
      type: 'deduction',
      reason,
    }]);
    
    console.log(`💳 Deducted ${amount} credits from ${email} (${reason}). Balance: ${newBalance}`);
    return newBalance;
  } catch (err) {
    console.error('Credit deduction failed:', err.message);
  }
}
