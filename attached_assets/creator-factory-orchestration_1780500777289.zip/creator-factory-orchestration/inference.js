// ============================================================
// INFERENCE ROUTE — Anthropic Claude + OpenRouter
// These are "smart" inference calls with system prompts,
// multi-turn memory, and structured output support
// ============================================================

const PROVIDERS = {
  anthropic: {
    models: {
      'claude-sonnet-4':   'claude-sonnet-4-20250514',
      'claude-opus-4':     'claude-opus-4-20250514',
      'claude-haiku-4':    'claude-haiku-4-5-20251001',
      'claude-opus-4-7':   'claude-opus-4-7-20250514',
    },
    defaultModel: 'claude-sonnet-4',
    baseURL: 'https://api.anthropic.com/v1',
    envKey: 'ANTHROPIC_API_KEY',
    creditsPerToken: 2,
  },
  openrouter: {
    models: {
      // Free models on OpenRouter
      'llama-4-scout':       'meta-llama/llama-4-scout',
      'llama-4-maverick':    'meta-llama/llama-4-maverick',
      'deepseek-r1':         'deepseek/deepseek-r1',
      'qwen-2.5-72b':        'qwen/qwen-2.5-72b-instruct',
      'gemini-flash':        'google/gemini-2.0-flash-exp:free',
      'mistral-small':       'mistralai/mistral-small-3.1',
      'phi-4':               'microsoft/phi-4',
      // Paid models
      'gpt-4o':              'openai/gpt-4o',
      'claude-sonnet':       'anthropic/claude-sonnet-4',
      'gemini-pro':          'google/gemini-2.5-pro',
    },
    defaultModel: 'llama-4-scout',
    baseURL: 'https://openrouter.ai/api/v1',
    envKey: 'OPENROUTER_API_KEY',
    creditsPerToken: 1,
  },
};

function resolveProvider(modelString) {
  if (!modelString) return { provider: 'openrouter', modelKey: 'llama-4-scout' };
  if (modelString.includes('/')) {
    const [provider, model] = modelString.split('/');
    return { provider, modelKey: model };
  }
  for (const [provider, config] of Object.entries(PROVIDERS)) {
    if (config.models[modelString]) return { provider, modelKey: modelString };
  }
  return { provider: 'openrouter', modelKey: 'llama-4-scout' };
}

// ── Anthropic Claude ──────────────────────────────────────
async function callAnthropic(prompt, modelKey, options = {}) {
  const config = PROVIDERS.anthropic;
  const model = config.models[modelKey] || config.models[config.defaultModel];

  const body = {
    model,
    max_tokens: options.maxTokens || 4096,
    messages: options.history || [{ role: 'user', content: prompt }],
    ...(options.systemPrompt && { system: options.systemPrompt }),
    ...(options.temperature && { temperature: options.temperature }),
  };

  // Structured output via tool use
  if (options.outputSchema) {
    body.tools = [{
      name: 'structured_output',
      description: 'Return structured data',
      input_schema: options.outputSchema,
    }];
    body.tool_choice = { type: 'tool', name: 'structured_output' };
  }

  const res = await fetch(`${config.baseURL}/messages`, {
    method: 'POST',
    headers: {
      'x-api-key': process.env[config.envKey],
      'anthropic-version': '2023-06-01',
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(body),
  });

  if (!res.ok) throw new Error(`Anthropic error: ${res.status} ${await res.text()}`);
  const data = await res.json();
  const usage = data.usage || {};

  // Handle tool use response (structured output)
  let output;
  if (options.outputSchema && data.content[0]?.type === 'tool_use') {
    output = data.content[0].input;
  } else {
    output = data.content.map(b => b.type === 'text' ? b.text : '').join('');
  }

  return {
    output,
    provider: 'anthropic',
    model,
    creditsUsed: Math.ceil((usage.input_tokens + usage.output_tokens) * config.creditsPerToken / 100),
    metadata: {
      inputTokens: usage.input_tokens,
      outputTokens: usage.output_tokens,
      stopReason: data.stop_reason,
    },
  };
}

// ── OpenRouter (unified gateway to 300+ models) ───────────
async function callOpenRouter(prompt, modelKey, options = {}) {
  const config = PROVIDERS.openrouter;
  const model = config.models[modelKey] || modelKey; // pass raw model ID if not in map

  const res = await fetch(`${config.baseURL}/chat/completions`, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${process.env[config.envKey]}`,
      'HTTP-Referer': process.env.APP_URL || 'https://creatorfactory.io',
      'X-Title': 'Creator Factory',
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      model,
      messages: options.history || [
        ...(options.systemPrompt ? [{ role: 'system', content: options.systemPrompt }] : []),
        { role: 'user', content: prompt },
      ],
      max_tokens: options.maxTokens || 4096,
      temperature: options.temperature ?? 0.7,
      ...(options.responseFormat && { response_format: options.responseFormat }),
      // OpenRouter extras
      transforms: options.transforms || [],
      route: options.route || 'fallback', // auto-selects cheapest working provider
    }),
  });

  if (!res.ok) throw new Error(`OpenRouter error: ${res.status} ${await res.text()}`);
  const data = await res.json();
  const usage = data.usage || {};

  return {
    output: data.choices[0].message.content,
    provider: 'openrouter',
    model: data.model || model, // OpenRouter returns actual model used
    creditsUsed: Math.ceil((usage.total_tokens || 0) * config.creditsPerToken / 100),
    metadata: {
      inputTokens: usage.prompt_tokens,
      outputTokens: usage.completion_tokens,
      actualModel: data.model,
      cost: data.usage?.cost,
    },
  };
}

const CALLERS = { anthropic: callAnthropic, openrouter: callOpenRouter };
const FALLBACK_CHAIN = ['anthropic', 'openrouter'];

export async function generateInference({ model, prompt, options = {} }) {
  const { provider: preferredProvider, modelKey } = resolveProvider(model);
  const chain = [preferredProvider, ...FALLBACK_CHAIN.filter(p => p !== preferredProvider)];
  const errors = [];

  for (const provider of chain) {
    const apiKey = process.env[PROVIDERS[provider]?.envKey];
    if (!apiKey) { errors.push(`${provider}: no API key`); continue; }
    try {
      console.log(`🧠 Inference via ${provider} [${modelKey}]...`);
      const result = await CALLERS[provider](prompt, modelKey, options);
      console.log(`✅ Inference success via ${provider}`);
      return result;
    } catch (err) {
      console.warn(`⚠️ ${provider} failed: ${err.message}`);
      errors.push(`${provider}: ${err.message}`);
    }
  }

  throw new Error(`All inference providers failed:\n${errors.join('\n')}`);
}
