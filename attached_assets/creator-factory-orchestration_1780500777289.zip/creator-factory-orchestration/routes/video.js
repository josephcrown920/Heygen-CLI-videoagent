// ============================================================
// VIDEO GENERATION ROUTER
// Chain: Fal (Kling 3.0) → Fal WAN → Replicate → RunPod
// ============================================================

const PROVIDERS = {
  fal: {
    models: {
      'kling-3.0':       'fal-ai/kling-video/v1.6/pro/image-to-video',
      'kling-text':      'fal-ai/kling-video/v1.6/pro/text-to-video',
      'wan-pro':         'fal-ai/wan-pro/v1.1/text-to-video',
      'wan-img':         'fal-ai/wan-pro/v1.1/image-to-video',
      'minimax':         'fal-ai/minimax/video-01',
      'luma':            'fal-ai/luma-dream-machine/ray-2-flash',
      'ltx-video':       'fal-ai/ltx-video',
    },
    defaultModel: 'kling-text',
    baseURL: 'https://fal.run',
    envKey: 'FAL_KEY',
    creditsPerSecond: 200,
  },
  replicate: {
    models: {
      'minimax':         'minimax/video-01',
      'wan-t2v':         'wavespeedai/wan-2.1-t2v-480p',
      'ltx-video':       'lightricks/ltx-video',
      'animate-diff':    'lucataco/animate-diff',
    },
    defaultModel: 'wan-t2v',
    baseURL: 'https://api.replicate.com/v1',
    envKey: 'REPLICATE_API_TOKEN',
    creditsPerSecond: 250,
  },
  runpod: {
    models: {
      'comfyui':         'comfyui',
      'wan-2.1':         'wan-2.1',
      'cogvideox':       'cogvideox',
    },
    defaultModel: 'comfyui',
    baseURL: null, // set via RUNPOD_ENDPOINT env
    envKey: 'RUNPOD_API_KEY',
    creditsPerSecond: 300,
  },
};

function resolveProvider(modelString) {
  if (!modelString) return { provider: 'fal', modelKey: 'kling-text' };
  if (modelString.includes('/')) {
    const [provider, model] = modelString.split('/');
    return { provider, modelKey: model };
  }
  for (const [provider, config] of Object.entries(PROVIDERS)) {
    if (config.models[modelString]) return { provider, modelKey: modelString };
  }
  return { provider: 'fal', modelKey: 'kling-text' };
}

// ── Fal AI Video ──────────────────────────────────────────
async function callFalVideo(prompt, modelKey, options = {}) {
  const config = PROVIDERS.fal;
  const modelPath = config.models[modelKey] || config.models[config.defaultModel];
  const isImageToVideo = modelPath.includes('image-to-video') || modelPath.includes('img');

  const payload = {
    prompt,
    duration: options.duration || 5,
    aspect_ratio: options.aspectRatio || '16:9',
    cfg_scale: options.cfgScale || 0.5,
    ...(isImageToVideo && options.imageUrl && { image_url: options.imageUrl }),
    ...(options.negativePrompt && { negative_prompt: options.negativePrompt }),
  };

  // Queue a job (video takes time)
  const submitRes = await fetch(`https://queue.fal.run/${modelPath}`, {
    method: 'POST',
    headers: {
      'Authorization': `Key ${process.env[config.envKey]}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(payload)
  });

  if (!submitRes.ok) throw new Error(`Fal video submit error: ${submitRes.status} ${await submitRes.text()}`);
  const { request_id } = await submitRes.json();
  
  console.log(`⏳ Fal video queued: ${request_id}`);

  // Poll for result (max 3 minutes)
  let attempts = 0;
  const maxAttempts = 90; // 90 × 2s = 3min

  while (attempts < maxAttempts) {
    await new Promise(r => setTimeout(r, 2000));
    
    const pollRes = await fetch(`https://queue.fal.run/${modelPath}/requests/${request_id}/status`, {
      headers: { 'Authorization': `Key ${process.env[config.envKey]}` }
    });
    
    const status = await pollRes.json();
    
    if (status.status === 'COMPLETED') {
      const resultRes = await fetch(`https://queue.fal.run/${modelPath}/requests/${request_id}`, {
        headers: { 'Authorization': `Key ${process.env[config.envKey]}` }
      });
      const result = await resultRes.json();
      const videoUrl = result.video?.url || result.output?.video_url;
      
      return {
        output: videoUrl,
        provider: 'fal',
        model: modelPath,
        creditsUsed: config.creditsPerSecond * (options.duration || 5),
        metadata: { requestId: request_id, duration: options.duration || 5 },
      };
    }
    
    if (status.status === 'FAILED') {
      throw new Error(`Fal video failed: ${status.error}`);
    }
    
    attempts++;
  }
  
  throw new Error('Fal video timed out after 3 minutes');
}

// ── Replicate Video ───────────────────────────────────────
async function callReplicateVideo(prompt, modelKey, options = {}) {
  const config = PROVIDERS.replicate;
  const model = config.models[modelKey] || config.models[config.defaultModel];
  
  const startRes = await fetch(`${config.baseURL}/models/${model}/predictions`, {
    method: 'POST',
    headers: {
      'Authorization': `Token ${process.env[config.envKey]}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      input: {
        prompt,
        duration: options.duration || 5,
        aspect_ratio: options.aspectRatio || '16:9',
        ...(options.imageUrl && { first_frame_image: options.imageUrl }),
      }
    })
  });
  
  if (!startRes.ok) throw new Error(`Replicate video start error: ${startRes.status}`);
  let prediction = await startRes.json();
  
  let attempts = 0;
  while (['starting', 'processing'].includes(prediction.status) && attempts < 90) {
    await new Promise(r => setTimeout(r, 2000));
    const pollRes = await fetch(`${config.baseURL}/predictions/${prediction.id}`, {
      headers: { 'Authorization': `Token ${process.env[config.envKey]}` }
    });
    prediction = await pollRes.json();
    attempts++;
  }
  
  if (prediction.status !== 'succeeded') {
    throw new Error(`Replicate video failed: ${prediction.error}`);
  }
  
  return {
    output: prediction.output,
    provider: 'replicate',
    model,
    creditsUsed: config.creditsPerSecond * (options.duration || 5),
    metadata: { predictionId: prediction.id },
  };
}

// ── RunPod (your custom ComfyUI endpoint) ────────────────
async function callRunPod(prompt, modelKey, options = {}) {
  const config = PROVIDERS.runpod;
  const endpoint = process.env.RUNPOD_ENDPOINT;
  if (!endpoint) throw new Error('RUNPOD_ENDPOINT not set');
  
  const res = await fetch(`${endpoint}/run`, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${process.env[config.envKey]}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      input: {
        prompt,
        workflow: modelKey || config.defaultModel,
        duration: options.duration || 5,
        width: options.width || 1280,
        height: options.height || 720,
        ...options.comfyInput,
      }
    })
  });
  
  if (!res.ok) throw new Error(`RunPod error: ${res.status} ${await res.text()}`);
  const { id } = await res.json();
  
  // Poll RunPod status
  let attempts = 0;
  while (attempts < 90) {
    await new Promise(r => setTimeout(r, 2000));
    const pollRes = await fetch(`${endpoint}/status/${id}`, {
      headers: { 'Authorization': `Bearer ${process.env[config.envKey]}` }
    });
    const status = await pollRes.json();
    
    if (status.status === 'COMPLETED') {
      return {
        output: status.output?.video_url || status.output,
        provider: 'runpod',
        model: modelKey,
        creditsUsed: config.creditsPerSecond * (options.duration || 5),
        metadata: { jobId: id },
      };
    }
    if (status.status === 'FAILED') throw new Error(`RunPod job failed: ${status.error}`);
    attempts++;
  }
  
  throw new Error('RunPod video timed out');
}

const CALLERS = { fal: callFalVideo, replicate: callReplicateVideo, runpod: callRunPod };
const FALLBACK_CHAIN = ['fal', 'replicate', 'runpod'];

export async function generateVideo({ model, prompt, options = {} }) {
  const { provider: preferredProvider, modelKey } = resolveProvider(model);
  const chain = [preferredProvider, ...FALLBACK_CHAIN.filter(p => p !== preferredProvider)];
  const errors = [];
  
  for (const provider of chain) {
    const envKey = PROVIDERS[provider]?.envKey;
    const hasKey = envKey && process.env[envKey];
    const hasEndpoint = provider !== 'runpod' || process.env.RUNPOD_ENDPOINT;
    
    if (!hasKey || !hasEndpoint) { errors.push(`${provider}: no API key/endpoint`); continue; }
    
    try {
      console.log(`🎬 Video generation via ${provider} [${modelKey}]...`);
      const result = await CALLERS[provider](prompt, modelKey, options);
      console.log(`✅ Video success via ${provider}`);
      return result;
    } catch (err) {
      console.warn(`⚠️ ${provider} failed: ${err.message}`);
      errors.push(`${provider}: ${err.message}`);
    }
  }
  
  throw new Error(`All video providers failed:\n${errors.join('\n')}`);
}
