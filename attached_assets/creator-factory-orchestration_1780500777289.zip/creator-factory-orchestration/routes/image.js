// ============================================================
// IMAGE GENERATION ROUTER
// Chain: Runware → Fal AI → Replicate → HuggingFace
// ============================================================

const PROVIDERS = {
  runware: {
    models: {
      'flux-dev':        '@cf/black-forest-labs/flux-1-dev',
      'flux-schnell':    'runware:100@1',
      'sdxl':            'runware:5@1',
      'realvis':         'runware:101@1',
    },
    defaultModel: 'flux-schnell',
    baseURL: 'https://api.runware.ai/v1',
    envKey: 'RUNWARE_API_KEY',
    creditsPerImage: 40,
  },
  fal: {
    models: {
      'flux-pro':        'fal-ai/flux-pro/v1.1',
      'flux-schnell':    'fal-ai/flux/schnell',
      'flux-dev':        'fal-ai/flux/dev',
      'ideogram-v3':     'fal-ai/ideogram/v3',
      'recraft-v3':      'fal-ai/recraft-v3',
      'stable-diffusion': 'fal-ai/stable-diffusion-v3-medium',
    },
    defaultModel: 'flux-schnell',
    baseURL: 'https://fal.run',
    envKey: 'FAL_KEY',
    creditsPerImage: 50,
  },
  replicate: {
    models: {
      'flux-schnell':    'black-forest-labs/flux-schnell',
      'flux-dev':        'black-forest-labs/flux-dev',
      'sdxl':            'stability-ai/sdxl',
      'recraft-v3':      'recraft-ai/recraft-v3',
    },
    defaultModel: 'flux-schnell',
    baseURL: 'https://api.replicate.com/v1',
    envKey: 'REPLICATE_API_TOKEN',
    creditsPerImage: 60,
  },
  huggingface: {
    models: {
      'sdxl':            'stabilityai/stable-diffusion-xl-base-1.0',
      'flux-dev':        'black-forest-labs/FLUX.1-dev',
      'flux-schnell':    'black-forest-labs/FLUX.1-schnell',
    },
    defaultModel: 'flux-schnell',
    baseURL: 'https://api-inference.huggingface.co/models',
    envKey: 'HUGGINGFACE_API_KEY',
    creditsPerImage: 20,
  },
};

function resolveProvider(modelString) {
  if (!modelString) return { provider: 'runware', modelKey: 'flux-schnell' };
  if (modelString.includes('/')) {
    const [provider, model] = modelString.split('/');
    return { provider, modelKey: model };
  }
  for (const [provider, config] of Object.entries(PROVIDERS)) {
    if (config.models[modelString]) return { provider, modelKey: modelString };
  }
  return { provider: 'runware', modelKey: 'flux-schnell' };
}

// ── Runware ───────────────────────────────────────────────
async function callRunware(prompt, modelKey, options = {}) {
  const config = PROVIDERS.runware;
  const model = config.models[modelKey] || config.models[config.defaultModel];
  
  const res = await fetch(`${config.baseURL}/images/generations`, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${process.env[config.envKey]}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      positivePrompt: prompt,
      negativePrompt: options.negativePrompt || 'blurry, low quality, ugly, distorted',
      model,
      numberResults: options.count || 1,
      width: options.width || 1024,
      height: options.height || 1024,
      outputFormat: 'WEBP',
      steps: options.steps || 20,
      CFGScale: options.cfgScale || 7,
      seed: options.seed || Math.floor(Math.random() * 999999),
    })
  });
  
  if (!res.ok) throw new Error(`Runware error: ${res.status} ${await res.text()}`);
  const data = await res.json();
  
  const urls = data.data?.map(img => img.imageURL) || [];
  return {
    output: options.count > 1 ? urls : urls[0],
    provider: 'runware',
    model,
    creditsUsed: config.creditsPerImage * (options.count || 1),
    metadata: { width: options.width || 1024, height: options.height || 1024 },
  };
}

// ── Fal AI ────────────────────────────────────────────────
async function callFal(prompt, modelKey, options = {}) {
  const config = PROVIDERS.fal;
  const modelPath = config.models[modelKey] || config.models[config.defaultModel];
  
  const res = await fetch(`${config.baseURL}/${modelPath}`, {
    method: 'POST',
    headers: {
      'Authorization': `Key ${process.env[config.envKey]}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      prompt,
      negative_prompt: options.negativePrompt || 'blurry, low quality',
      image_size: options.imageSize || 'landscape_4_3',
      num_images: options.count || 1,
      num_inference_steps: options.steps || 28,
      guidance_scale: options.cfgScale || 3.5,
      enable_safety_checker: true,
      sync_mode: true,
    })
  });
  
  if (!res.ok) throw new Error(`Fal error: ${res.status} ${await res.text()}`);
  const data = await res.json();
  
  const urls = data.images?.map(img => img.url) || [];
  return {
    output: options.count > 1 ? urls : urls[0],
    provider: 'fal',
    model: modelPath,
    creditsUsed: config.creditsPerImage * (options.count || 1),
    metadata: { seed: data.seed, hasNSFW: data.has_nsfw_concepts?.[0] },
  };
}

// ── Replicate ─────────────────────────────────────────────
async function callReplicate(prompt, modelKey, options = {}) {
  const config = PROVIDERS.replicate;
  const model = config.models[modelKey] || config.models[config.defaultModel];
  
  // Start prediction
  const startRes = await fetch(`${config.baseURL}/models/${model}/predictions`, {
    method: 'POST',
    headers: {
      'Authorization': `Token ${process.env[config.envKey]}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      input: {
        prompt,
        negative_prompt: options.negativePrompt || 'blurry, low quality',
        width: options.width || 1024,
        height: options.height || 1024,
        num_outputs: options.count || 1,
        num_inference_steps: options.steps || 4,
        guidance_scale: options.cfgScale || 0,
      }
    })
  });
  
  if (!startRes.ok) throw new Error(`Replicate start error: ${startRes.status}`);
  let prediction = await startRes.json();
  
  // Poll for completion (max 60s)
  let attempts = 0;
  while (['starting', 'processing'].includes(prediction.status) && attempts < 30) {
    await new Promise(r => setTimeout(r, 2000));
    const pollRes = await fetch(`${config.baseURL}/predictions/${prediction.id}`, {
      headers: { 'Authorization': `Token ${process.env[config.envKey]}` }
    });
    prediction = await pollRes.json();
    attempts++;
  }
  
  if (prediction.status !== 'succeeded') {
    throw new Error(`Replicate prediction failed: ${prediction.status} — ${prediction.error}`);
  }
  
  const urls = prediction.output || [];
  return {
    output: options.count > 1 ? urls : urls[0],
    provider: 'replicate',
    model,
    creditsUsed: config.creditsPerImage * (options.count || 1),
    metadata: { predictionId: prediction.id },
  };
}

// ── HuggingFace ───────────────────────────────────────────
async function callHuggingFace(prompt, modelKey, options = {}) {
  const config = PROVIDERS.huggingface;
  const model = config.models[modelKey] || config.models[config.defaultModel];
  
  const res = await fetch(`${config.baseURL}/${model}`, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${process.env[config.envKey]}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      inputs: prompt,
      parameters: {
        negative_prompt: options.negativePrompt || 'blurry, low quality',
        width: options.width || 1024,
        height: options.height || 1024,
        num_inference_steps: options.steps || 20,
        guidance_scale: options.cfgScale || 7.5,
      }
    })
  });
  
  if (!res.ok) throw new Error(`HuggingFace error: ${res.status} ${await res.text()}`);
  
  // Returns binary blob → convert to base64 data URL
  const buffer = await res.arrayBuffer();
  const base64 = Buffer.from(buffer).toString('base64');
  const imageUrl = `data:image/png;base64,${base64}`;
  
  return {
    output: imageUrl,
    provider: 'huggingface',
    model,
    creditsUsed: config.creditsPerImage,
    metadata: { format: 'base64' },
  };
}

const CALLERS = { runware: callRunware, fal: callFal, replicate: callReplicate, huggingface: callHuggingFace };
const FALLBACK_CHAIN = ['runware', 'fal', 'replicate', 'huggingface'];

export async function generateImage({ model, prompt, options = {} }) {
  const { provider: preferredProvider, modelKey } = resolveProvider(model);
  const chain = [preferredProvider, ...FALLBACK_CHAIN.filter(p => p !== preferredProvider)];
  const errors = [];
  
  for (const provider of chain) {
    const apiKey = process.env[PROVIDERS[provider]?.envKey];
    if (!apiKey) { errors.push(`${provider}: no API key`); continue; }
    try {
      console.log(`🎨 Image generation via ${provider}...`);
      const result = await CALLERS[provider](prompt, modelKey, options);
      console.log(`✅ Image success via ${provider}`);
      return result;
    } catch (err) {
      console.warn(`⚠️ ${provider} failed: ${err.message}`);
      errors.push(`${provider}: ${err.message}`);
    }
  }
  
  throw new Error(`All image providers failed:\n${errors.join('\n')}`);
}
