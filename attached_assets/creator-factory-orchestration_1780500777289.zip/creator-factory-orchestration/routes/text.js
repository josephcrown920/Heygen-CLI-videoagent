// ============================================================
// TEXT GENERATION ROUTER
// Chain: Groq → Gemini → Mistral → OpenAI → Cohere → Together
// ============================================================

const PROVIDERS = {
  groq: {
    models: {
      'llama-4-scout':    'meta-llama/llama-4-scout-17b-16e-instruct',
      'llama-4-maverick': 'meta-llama/llama-4-maverick-17b-128e-instruct',
      'mixtral':          'mixtral-8x7b-32768',
      'gemma2':           'gemma2-9b-it',
    },
    defaultModel: 'llama-4-scout',
    baseURL: 'https://api.groq.com/openai/v1',
    envKey: 'GROQ_API_KEY',
    rateLimit: 30, // requests per minute
    creditsPerToken: 0.5,
    free: true,
  },
  gemini: {
    models: {
      'flash-2.0':     'gemini-2.0-flash',
      'flash-lite':    'gemini-2.0-flash-lite',
      'pro-2.0':       'gemini-2.0-pro-exp',
      'flash-1.5':     'gemini-1.5-flash',
    },
    defaultModel: 'flash-2.0',
    baseURL: 'https://generativelanguage.googleapis.com/v1beta',
    envKey: 'GOOGLE_AI_KEY',
    creditsPerToken: 0.5,
    free: true,
  },
  mistral: {
    models: {
      'mistral-large':  'mistral-large-latest',
      'mistral-small':  'mistral-small-latest',
      'codestral':      'codestral-latest',
      'nemo':           'open-mistral-nemo',
    },
    defaultModel: 'nemo',
    baseURL: 'https://api.mistral.ai/v1',
    envKey: 'MISTRAL_API_KEY',
    creditsPerToken: 1,
    free: false,
  },
  openai: {
    models: {
      'gpt-4o':       'gpt-4o',
      'gpt-4o-mini':  'gpt-4o-mini',
      'o3-mini':      'o3-mini',
    },
    defaultModel: 'gpt-4o-mini',
    baseURL: 'https://api.openai.com/v1',
    envKey: 'OPENAI_API_KEY',
    creditsPerToken: 2,
    free: false,
  },
  cohere: {
    models: {
      'command-r-plus': 'command-r-plus',
      'command-r':      'command-r',
      'command':        'command',
    },
    defaultModel: 'command-r',
    baseURL: 'https://api.cohere.com/v1',
    envKey: 'COHERE_API_KEY',
    creditsPerToken: 1,
    free: true, // free trial key available
  },
  together: {
    models: {
      'llama-4':       'meta-llama/Llama-4-Scout-17B-16E-Instruct',
      'deepseek-r1':   'deepseek-ai/DeepSeek-R1',
      'qwen-2.5':      'Qwen/Qwen2.5-72B-Instruct-Turbo',
    },
    defaultModel: 'llama-4',
    baseURL: 'https://api.together.xyz/v1',
    envKey: 'TOGETHER_API_KEY',
    creditsPerToken: 0.5,
    free: false,
  },
};

// Parse "provider/model" or just pick best available
function resolveProvider(modelString) {
  if (!modelString) return { provider: 'groq', modelKey: 'llama-4-scout' };
  
  if (modelString.includes('/')) {
    const [provider, model] = modelString.split('/');
    return { provider, modelKey: model };
  }
  
  // Auto-detect by model name
  for (const [provider, config] of Object.entries(PROVIDERS)) {
    if (config.models[modelString]) return { provider, modelKey: modelString };
  }
  
  return { provider: 'groq', modelKey: 'llama-4-scout' };
}

// ── Groq (OpenAI-compatible) ──────────────────────────────
async function callGroq(prompt, modelKey, options = {}) {
  const config = PROVIDERS.groq;
  const model = config.models[modelKey] || config.models[config.defaultModel];
  
  const res = await fetch(`${config.baseURL}/chat/completions`, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${process.env[config.envKey]}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      model,
      messages: [
        ...(options.systemPrompt ? [{ role: 'system', content: options.systemPrompt }] : []),
        { role: 'user', content: prompt }
      ],
      max_tokens: options.maxTokens || 2048,
      temperature: options.temperature ?? 0.7,
      stream: false,
    })
  });
  
  if (!res.ok) throw new Error(`Groq error: ${res.status} ${await res.text()}`);
  const data = await res.json();
  const usage = data.usage || {};
  
  return {
    output: data.choices[0].message.content,
    provider: 'groq',
    model,
    creditsUsed: Math.ceil((usage.total_tokens || 0) * config.creditsPerToken / 100),
    metadata: { inputTokens: usage.prompt_tokens, outputTokens: usage.completion_tokens },
  };
}

// ── Gemini ────────────────────────────────────────────────
async function callGemini(prompt, modelKey, options = {}) {
  const config = PROVIDERS.gemini;
  const model = config.models[modelKey] || config.models[config.defaultModel];
  const apiKey = process.env[config.envKey];
  
  const res = await fetch(
    `${config.baseURL}/models/${model}:generateContent?key=${apiKey}`,
    {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        contents: [{ role: 'user', parts: [{ text: prompt }] }],
        ...(options.systemPrompt && {
          systemInstruction: { parts: [{ text: options.systemPrompt }] }
        }),
        generationConfig: {
          maxOutputTokens: options.maxTokens || 2048,
          temperature: options.temperature ?? 0.7,
        }
      })
    }
  );
  
  if (!res.ok) throw new Error(`Gemini error: ${res.status} ${await res.text()}`);
  const data = await res.json();
  const usage = data.usageMetadata || {};
  
  return {
    output: data.candidates[0].content.parts[0].text,
    provider: 'gemini',
    model,
    creditsUsed: Math.ceil((usage.totalTokenCount || 0) * config.creditsPerToken / 100),
    metadata: { inputTokens: usage.promptTokenCount, outputTokens: usage.candidatesTokenCount },
  };
}

// ── Mistral (OpenAI-compatible) ───────────────────────────
async function callMistral(prompt, modelKey, options = {}) {
  const config = PROVIDERS.mistral;
  const model = config.models[modelKey] || config.models[config.defaultModel];
  
  const res = await fetch(`${config.baseURL}/chat/completions`, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${process.env[config.envKey]}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      model,
      messages: [
        ...(options.systemPrompt ? [{ role: 'system', content: options.systemPrompt }] : []),
        { role: 'user', content: prompt }
      ],
      max_tokens: options.maxTokens || 2048,
      temperature: options.temperature ?? 0.7,
    })
  });
  
  if (!res.ok) throw new Error(`Mistral error: ${res.status} ${await res.text()}`);
  const data = await res.json();
  const usage = data.usage || {};
  
  return {
    output: data.choices[0].message.content,
    provider: 'mistral',
    model,
    creditsUsed: Math.ceil((usage.total_tokens || 0) * config.creditsPerToken / 100),
    metadata: { inputTokens: usage.prompt_tokens, outputTokens: usage.completion_tokens },
  };
}

// ── OpenAI ────────────────────────────────────────────────
async function callOpenAI(prompt, modelKey, options = {}) {
  const config = PROVIDERS.openai;
  const model = config.models[modelKey] || config.models[config.defaultModel];
  
  const res = await fetch(`${config.baseURL}/chat/completions`, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${process.env[config.envKey]}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      model,
      messages: [
        ...(options.systemPrompt ? [{ role: 'system', content: options.systemPrompt }] : []),
        { role: 'user', content: prompt }
      ],
      max_tokens: options.maxTokens || 2048,
      temperature: options.temperature ?? 0.7,
    })
  });
  
  if (!res.ok) throw new Error(`OpenAI error: ${res.status} ${await res.text()}`);
  const data = await res.json();
  const usage = data.usage || {};
  
  return {
    output: data.choices[0].message.content,
    provider: 'openai',
    model,
    creditsUsed: Math.ceil((usage.total_tokens || 0) * config.creditsPerToken / 100),
    metadata: { inputTokens: usage.prompt_tokens, outputTokens: usage.completion_tokens },
  };
}

// ── Cohere ────────────────────────────────────────────────
async function callCohere(prompt, modelKey, options = {}) {
  const config = PROVIDERS.cohere;
  const model = config.models[modelKey] || config.models[config.defaultModel];
  
  const res = await fetch(`${config.baseURL}/chat`, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${process.env[config.envKey]}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      model,
      message: prompt,
      ...(options.systemPrompt && { preamble: options.systemPrompt }),
      max_tokens: options.maxTokens || 2048,
      temperature: options.temperature ?? 0.7,
    })
  });
  
  if (!res.ok) throw new Error(`Cohere error: ${res.status} ${await res.text()}`);
  const data = await res.json();
  const usage = data.meta?.tokens || {};
  
  return {
    output: data.text,
    provider: 'cohere',
    model,
    creditsUsed: Math.ceil(((usage.input_tokens || 0) + (usage.output_tokens || 0)) * config.creditsPerToken / 100),
    metadata: { inputTokens: usage.input_tokens, outputTokens: usage.output_tokens },
  };
}

// ── Together AI (OpenAI-compatible) ──────────────────────
async function callTogether(prompt, modelKey, options = {}) {
  const config = PROVIDERS.together;
  const model = config.models[modelKey] || config.models[config.defaultModel];
  
  const res = await fetch(`${config.baseURL}/chat/completions`, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${process.env[config.envKey]}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      model,
      messages: [
        ...(options.systemPrompt ? [{ role: 'system', content: options.systemPrompt }] : []),
        { role: 'user', content: prompt }
      ],
      max_tokens: options.maxTokens || 2048,
      temperature: options.temperature ?? 0.7,
    })
  });
  
  if (!res.ok) throw new Error(`Together error: ${res.status} ${await res.text()}`);
  const data = await res.json();
  const usage = data.usage || {};
  
  return {
    output: data.choices[0].message.content,
    provider: 'together',
    model,
    creditsUsed: Math.ceil((usage.total_tokens || 0) * config.creditsPerToken / 100),
    metadata: { inputTokens: usage.prompt_tokens, outputTokens: usage.completion_tokens },
  };
}

// ── Provider dispatch map ─────────────────────────────────
const CALLERS = {
  groq:    callGroq,
  gemini:  callGemini,
  mistral: callMistral,
  openai:  callOpenAI,
  cohere:  callCohere,
  together: callTogether,
};

// ── Fallback chain (free-tier first) ─────────────────────
const FALLBACK_CHAIN = ['groq', 'gemini', 'cohere', 'together', 'mistral', 'openai'];

// ── Main export ───────────────────────────────────────────
export async function generateText({ model, prompt, options = {} }) {
  const { provider: preferredProvider, modelKey } = resolveProvider(model);
  
  // Build chain: preferred first, then fallbacks
  const chain = [
    preferredProvider,
    ...FALLBACK_CHAIN.filter(p => p !== preferredProvider)
  ];
  
  const errors = [];
  
  for (const provider of chain) {
    const apiKey = process.env[PROVIDERS[provider]?.envKey];
    if (!apiKey) {
      errors.push(`${provider}: no API key`);
      continue;
    }
    
    try {
      console.log(`🔤 Text generation via ${provider}...`);
      const result = await CALLERS[provider](prompt, modelKey, options);
      console.log(`✅ Text success via ${provider}`);
      return result;
    } catch (err) {
      console.warn(`⚠️ ${provider} failed: ${err.message}`);
      errors.push(`${provider}: ${err.message}`);
    }
  }
  
  throw new Error(`All text providers failed:\n${errors.join('\n')}`);
}
