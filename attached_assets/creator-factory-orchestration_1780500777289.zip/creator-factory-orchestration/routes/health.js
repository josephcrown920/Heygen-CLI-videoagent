// routes/health.js
// ============================================================
// HEALTH CHECK — pings all providers and reports key status
// ============================================================

const PROVIDER_CHECKS = [
  { name: 'Groq',        key: 'GROQ_API_KEY',          type: 'text' },
  { name: 'Gemini',      key: 'GOOGLE_AI_KEY',          type: 'text' },
  { name: 'Mistral',     key: 'MISTRAL_API_KEY',        type: 'text' },
  { name: 'OpenAI',      key: 'OPENAI_API_KEY',         type: 'text' },
  { name: 'Cohere',      key: 'COHERE_API_KEY',         type: 'text' },
  { name: 'Together',    key: 'TOGETHER_API_KEY',       type: 'text' },
  { name: 'Runware',     key: 'RUNWARE_API_KEY',        type: 'image' },
  { name: 'Fal AI',      key: 'FAL_KEY',                type: 'image/video' },
  { name: 'Replicate',   key: 'REPLICATE_API_TOKEN',    type: 'image/video/audio' },
  { name: 'HuggingFace', key: 'HUGGINGFACE_API_KEY',    type: 'image/audio' },
  { name: 'ElevenLabs',  key: 'ELEVENLABS_API_KEY',     type: 'audio' },
  { name: 'RunPod',      key: 'RUNPOD_API_KEY',         type: 'video' },
];

export async function healthCheck(req, res) {
  const providers = PROVIDER_CHECKS.map(p => ({
    name: p.name,
    type: p.type,
    status: process.env[p.key] ? '✅ configured' : '❌ missing key',
    key: p.key,
  }));

  const configured = providers.filter(p => p.status.includes('✅')).length;
  const missing = providers.filter(p => p.status.includes('❌')).length;

  res.json({
    status: configured > 0 ? 'operational' : 'no providers configured',
    uptime: process.uptime(),
    providers,
    summary: { configured, missing, total: providers.length },
    endpoints: {
      generate: 'POST /api/generate',
      health:   'GET /api/health',
      credits:  'GET /api/credits/:email',
      providers: 'GET /api/providers',
      pricing:  'GET /api/pricing',
      webhook:  'POST /webhooks/paystack',
    }
  });
}
