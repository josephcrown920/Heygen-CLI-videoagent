// ============================================================
// AUDIO GENERATION ROUTER
// Chain: ElevenLabs → Replicate (MusicGen/Bark) → HuggingFace
// ============================================================

const PROVIDERS = {
  elevenlabs: {
    models: {
      'multilingual-v2': 'eleven_multilingual_v2',
      'turbo-v2':        'eleven_turbo_v2',
      'turbo-v2-5':      'eleven_turbo_v2_5',
      'monolingual-v1':  'eleven_monolingual_v1',
    },
    defaultModel: 'multilingual-v2',
    baseURL: 'https://api.elevenlabs.io/v1',
    envKey: 'ELEVENLABS_API_KEY',
    creditsPerMinute: 100,
    type: 'tts',
  },
  replicate: {
    models: {
      'musicgen':   'meta/musicgen:671ac645ce5e552cc63a54a2bbff63fcf798043692ded668abca7dd32e3e8b4d',
      'bark':       'suno-ai/bark:b76242b40d67c76ab6742e987628a2a9ac019e11d56ab96c4e91ce03b79b2787',
      'riffusion':  'riffusion/riffusion:8cf61ea6c56afd61d8f5b9ffd14d7c216c0a93844ce2d82ac1c9ecc9c7f24e05',
    },
    defaultModel: 'musicgen',
    baseURL: 'https://api.replicate.com/v1',
    envKey: 'REPLICATE_API_TOKEN',
    creditsPerMinute: 120,
    type: 'music',
  },
  huggingface: {
    models: {
      'speecht5':    'microsoft/speecht5_tts',
      'musicgen':    'facebook/musicgen-small',
      'bark':        'suno/bark',
    },
    defaultModel: 'musicgen',
    baseURL: 'https://api-inference.huggingface.co/models',
    envKey: 'HUGGINGFACE_API_KEY',
    creditsPerMinute: 50,
    type: 'both',
  },
};

function resolveProvider(modelString) {
  if (!modelString) return { provider: 'elevenlabs', modelKey: 'multilingual-v2' };
  if (modelString.includes('/')) {
    const [provider, model] = modelString.split('/');
    return { provider, modelKey: model };
  }
  for (const [provider, config] of Object.entries(PROVIDERS)) {
    if (config.models[modelString]) return { provider, modelKey: modelString };
  }
  return { provider: 'elevenlabs', modelKey: 'multilingual-v2' };
}

// ── ElevenLabs TTS ────────────────────────────────────────
async function callElevenLabs(prompt, modelKey, options = {}) {
  const config = PROVIDERS.elevenlabs;
  const model = config.models[modelKey] || config.models[config.defaultModel];
  const voiceId = options.voiceId || 'pNInz6obpgDQGcFmaJgB'; // Adam (default)
  
  const res = await fetch(`${config.baseURL}/text-to-speech/${voiceId}`, {
    method: 'POST',
    headers: {
      'xi-api-key': process.env[config.envKey],
      'Content-Type': 'application/json',
      'Accept': 'audio/mpeg',
    },
    body: JSON.stringify({
      text: prompt,
      model_id: model,
      voice_settings: {
        stability: options.stability || 0.5,
        similarity_boost: options.similarityBoost || 0.75,
        style: options.style || 0,
        use_speaker_boost: options.speakerBoost ?? true,
      }
    })
  });
  
  if (!res.ok) throw new Error(`ElevenLabs error: ${res.status} ${await res.text()}`);
  
  // Convert to base64
  const buffer = await res.arrayBuffer();
  const base64 = Buffer.from(buffer).toString('base64');
  const estimatedMinutes = prompt.length / 800; // ~800 chars/min speaking
  
  return {
    output: `data:audio/mpeg;base64,${base64}`,
    provider: 'elevenlabs',
    model,
    creditsUsed: Math.ceil(config.creditsPerMinute * estimatedMinutes),
    metadata: { voiceId, format: 'mp3', type: 'tts' },
  };
}

// ── Replicate Audio (MusicGen / Bark) ─────────────────────
async function callReplicateAudio(prompt, modelKey, options = {}) {
  const config = PROVIDERS.replicate;
  const modelId = config.models[modelKey] || config.models[config.defaultModel];
  
  // Payload differs per model
  const inputMap = {
    musicgen: {
      prompt,
      duration: options.duration || 15,
      model_version: options.musicgenVersion || 'stereo-large',
      output_format: 'mp3',
      normalization_strategy: 'peak',
    },
    bark: {
      prompt,
      text_temp: options.textTemp || 0.7,
      waveform_temp: options.waveformTemp || 0.7,
    },
    riffusion: {
      prompt_a: prompt,
      denoising: options.denoising || 0.75,
      num_inference_steps: options.steps || 50,
    },
  };
  
  const input = inputMap[modelKey] || inputMap.musicgen;
  
  const startRes = await fetch(`${config.baseURL}/predictions`, {
    method: 'POST',
    headers: {
      'Authorization': `Token ${process.env[config.envKey]}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ version: modelId.split(':')[1] || modelId, input })
  });
  
  if (!startRes.ok) throw new Error(`Replicate audio start error: ${startRes.status}`);
  let prediction = await startRes.json();
  
  let attempts = 0;
  while (['starting', 'processing'].includes(prediction.status) && attempts < 60) {
    await new Promise(r => setTimeout(r, 2000));
    const pollRes = await fetch(`${config.baseURL}/predictions/${prediction.id}`, {
      headers: { 'Authorization': `Token ${process.env[config.envKey]}` }
    });
    prediction = await pollRes.json();
    attempts++;
  }
  
  if (prediction.status !== 'succeeded') {
    throw new Error(`Replicate audio failed: ${prediction.error}`);
  }
  
  const audioUrl = Array.isArray(prediction.output) ? prediction.output[0] : prediction.output;
  const duration = options.duration || 15;
  
  return {
    output: audioUrl,
    provider: 'replicate',
    model: modelKey,
    creditsUsed: Math.ceil(config.creditsPerMinute * (duration / 60)),
    metadata: { predictionId: prediction.id, type: modelKey === 'bark' ? 'tts' : 'music' },
  };
}

// ── HuggingFace Audio ─────────────────────────────────────
async function callHuggingFaceAudio(prompt, modelKey, options = {}) {
  const config = PROVIDERS.huggingface;
  const model = config.models[modelKey] || config.models[config.defaultModel];
  
  const res = await fetch(`${config.baseURL}/${model}`, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${process.env[config.envKey]}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      inputs: prompt,
      parameters: {
        ...(modelKey === 'speecht5' && { speaker_embeddings: options.speakerEmbeddings }),
        max_new_tokens: options.maxTokens || 256,
      }
    })
  });
  
  if (!res.ok) throw new Error(`HuggingFace audio error: ${res.status} ${await res.text()}`);
  
  const buffer = await res.arrayBuffer();
  const base64 = Buffer.from(buffer).toString('base64');
  
  return {
    output: `data:audio/wav;base64,${base64}`,
    provider: 'huggingface',
    model,
    creditsUsed: config.creditsPerMinute,
    metadata: { format: 'wav', type: modelKey === 'speecht5' ? 'tts' : 'music' },
  };
}

const CALLERS = {
  elevenlabs: callElevenLabs,
  replicate:  callReplicateAudio,
  huggingface: callHuggingFaceAudio,
};
const FALLBACK_CHAIN = ['elevenlabs', 'replicate', 'huggingface'];

export async function generateAudio({ model, prompt, options = {} }) {
  const { provider: preferredProvider, modelKey } = resolveProvider(model);
  const chain = [preferredProvider, ...FALLBACK_CHAIN.filter(p => p !== preferredProvider)];
  const errors = [];
  
  for (const provider of chain) {
    const apiKey = process.env[PROVIDERS[provider]?.envKey];
    if (!apiKey) { errors.push(`${provider}: no API key`); continue; }
    try {
      console.log(`🎵 Audio generation via ${provider} [${modelKey}]...`);
      const result = await CALLERS[provider](prompt, modelKey, options);
      console.log(`✅ Audio success via ${provider}`);
      return result;
    } catch (err) {
      console.warn(`⚠️ ${provider} failed: ${err.message}`);
      errors.push(`${provider}: ${err.message}`);
    }
  }
  
  throw new Error(`All audio providers failed:\n${errors.join('\n')}`);
}
