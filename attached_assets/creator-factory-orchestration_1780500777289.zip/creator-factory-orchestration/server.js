// ============================================================
// CREATOR FACTORY — UNIFIED AI ORCHESTRATION SERVER
// POST /api/generate → routes to any provider automatically
// Supports: Text | Image | Video | Audio
// ============================================================

import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import { createClient } from '@supabase/supabase-js';
import crypto from 'crypto';

import { generateText } from './routes/text.js';
import { generateImage } from './routes/image.js';
import { generateVideo } from './routes/video.js';
import { generateAudio } from './routes/audio.js';
import { healthCheck } from './routes/health.js';
import { deductCredits, checkCredits } from './middleware/credits.js';
import { logger } from './utils/logger.js';

dotenv.config();

const app = express();
app.use(cors());
app.use(express.json({ limit: '10mb' }));
app.use(logger);

// ============================================================
// SUPABASE
// ============================================================
export const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_KEY
);

// ============================================================
// PAYSTACK WEBHOOK (from your existing credit system)
// ============================================================
app.post('/webhooks/paystack', async (req, res) => {
  const signature = req.headers['x-paystack-signature'];
  const hash = crypto
    .createHmac('sha512', process.env.PAYSTACK_SECRET_KEY)
    .update(JSON.stringify(req.body))
    .digest('hex');

  if (hash !== signature) return res.status(400).json({ error: 'Invalid signature' });

  const event = req.body;
  if (event.event === 'charge.success') {
    const { reference, amount, customer } = event.data;
    const email = customer.email;
    const amountNaira = Math.floor(amount / 100);
    const credits = Math.floor(amountNaira * 0.4); // 40% to user
    const profit = amountNaira - credits;

    let { data: user } = await supabase.from('users').select('*').eq('email', email).single();
    if (!user) {
      const { data: newUser } = await supabase.from('users')
        .insert([{ email, total_credits: credits }]).select().single();
      user = newUser;
    } else {
      await supabase.from('users').update({ total_credits: user.total_credits + credits }).eq('id', user.id);
    }
    await supabase.from('purchases').insert([{
      user_id: user.id, paystack_reference: reference,
      amount_paid: amountNaira, credits_allocated: credits, profit_kept: profit
    }]);
    console.log(`✅ Payment processed: ₦${amountNaira} → ${credits} credits for ${email}`);
  }
  res.json({ success: true });
});

// ============================================================
// CORE UNIFIED ENDPOINT
// POST /api/generate
// Body: { type, model, prompt, options, userEmail }
// ============================================================
app.post('/api/generate', checkCredits, async (req, res) => {
  const { type, model, prompt, options = {}, userEmail } = req.body;

  if (!type || !prompt) {
    return res.status(400).json({ error: 'Missing required fields: type, prompt' });
  }

  const validTypes = ['text', 'image', 'video', 'audio'];
  if (!validTypes.includes(type)) {
    return res.status(400).json({ error: `Invalid type. Must be one of: ${validTypes.join(', ')}` });
  }

  try {
    let result;
    const startTime = Date.now();

    switch (type) {
      case 'text':  result = await generateText({ model, prompt, options }); break;
      case 'image': result = await generateImage({ model, prompt, options }); break;
      case 'video': result = await generateVideo({ model, prompt, options }); break;
      case 'audio': result = await generateAudio({ model, prompt, options }); break;
    }

    const duration = Date.now() - startTime;

    // Deduct credits if userEmail provided
    if (userEmail && result.creditsUsed) {
      await deductCredits(userEmail, result.creditsUsed, `${type}/${result.provider}`);
    }

    res.json({
      success: true,
      type,
      provider: result.provider,
      model: result.model,
      output: result.output,
      creditsUsed: result.creditsUsed || 0,
      duration,
      metadata: result.metadata || {}
    });

  } catch (error) {
    console.error(`❌ Generation failed [${type}]:`, error.message);
    res.status(500).json({ 
      success: false, 
      error: error.message,
      type,
      fallbackSuggestion: 'Retry with different model or check provider status'
    });
  }
});

// ============================================================
// ADDITIONAL ENDPOINTS
// ============================================================
app.get('/api/health', healthCheck);

app.get('/api/credits/:email', async (req, res) => {
  const { data: user } = await supabase.from('users').select('total_credits').eq('email', req.params.email).single();
  if (!user) return res.status(404).json({ error: 'User not found' });
  res.json({ credits: user.total_credits });
});

app.get('/api/providers', (req, res) => {
  res.json({
    text:  ['groq/llama-4-scout', 'groq/llama-4-maverick', 'gemini/flash-2.0', 'gemini/pro-2.0', 'mistral/mistral-large', 'mistral/codestral', 'openai/gpt-4o', 'cohere/command-r-plus', 'together/llama-4'],
    image: ['runware/flux-dev', 'runware/sdxl', 'fal/flux-pro', 'fal/ideogram-v3', 'replicate/flux-schnell', 'huggingface/sdxl'],
    video: ['fal/kling-3.0', 'fal/wan-pro', 'replicate/minimax-video', 'runpod/comfyui'],
    audio: ['elevenlabs/multilingual-v2', 'replicate/musicgen', 'replicate/bark', 'huggingface/speecht5']
  });
});

app.get('/api/pricing', (req, res) => {
  res.json({
    text:  { costPer1kTokens: 1 },
    image: { costPerImage: 50 },
    video: { costPerSecond: 200 },
    audio: { costPerMinute: 100 }
  });
});

// ============================================================
// START
// ============================================================
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`
  🚀 CREATOR FACTORY — AI ORCHESTRATION LIVE
  ═══════════════════════════════════════════════
  Server:   http://localhost:${PORT}
  Endpoint: POST /api/generate
  Types:    text | image | video | audio
  ───────────────────────────────────────────────
  Text:     Groq → Gemini → Mistral → Cohere
  Image:    Runware → Fal → Replicate → HuggingFace
  Video:    Kling (Fal) → WAN → Replicate → RunPod
  Audio:    ElevenLabs → Replicate → HuggingFace
  ═══════════════════════════════════════════════
  `);
});

export default app;
