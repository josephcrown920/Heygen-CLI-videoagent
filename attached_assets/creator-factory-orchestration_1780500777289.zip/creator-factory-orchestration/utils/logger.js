// utils/logger.js
export function logger(req, res, next) {
  const start = Date.now();
  res.on('finish', () => {
    const duration = Date.now() - start;
    const icon = res.statusCode < 400 ? '✅' : '❌';
    console.log(`${icon} ${req.method} ${req.path} → ${res.statusCode} (${duration}ms)`);
  });
  next();
}
