# Creator Factory — AI Orchestration Layer v2

Unified backend API routing AI jobs across every provider. One endpoint, all modalities.

---

## Architecture

```
Frontend (Lovable / React)
        ↓
POST /api/generate | /api/inference | /api/sync
        ↓
Orchestration Router (this repo)
        ↓
┌─────────────────────────────────────────────────┐
│  TEXT      Groq → Gemini → Mistral → Cohere     │
│  IMAGE     Runware → Fal → Replicate → HF       │
│  VIDEO     Kling (Fal) → WAN → Replicate        │
│  AUDIO     ElevenLabs → MusicGen → HF           │
│  INFERENCE Anthropic → OpenRouter               │
│  SYNC      Sync.so → Replicate (Wav2Lip)        │
└─────────────────────────────────────────────────┘
        ↓
Supabase (credit deduction + profit tracking)
        ↑
Paystack Webhook (auto credit allocation)
```

---

## Setup

### 1. Install

```bash
npm install
cp .env.example .env
# fill in your keys
npm run dev
```

### 2. Verify

```bash
curl http://localhost:5000/api/health
```

---

## Endpoints

### `POST /api/generate`
General generation for text, image, video, audio.

```json
{
  "type": "text",
  "model": "groq/llama-4-scout",
  "prompt": "Write a hook for an Afrobeats track",
  "options": {
    "temperature": 0.9,
    "maxTokens": 512,
    "systemPrompt": "You are a music lyricist"
  },
  "userEmail": "user@example.com"
}
```

**Model format:** `provider/model-name` or just `model-name`

| Type | Providers | Example Model |
|------|-----------|---------------|
| text | groq, gemini, mistral, openai, cohere, together | `groq/llama-4-scout` |
| image | runware, fal, replicate, huggingface | `fal/flux-pro` |
| video | fal, replicate, runpod | `fal/kling-3.0` |
| audio | elevenlabs, replicate, huggingface | `elevenlabs/multilingual-v2` |

---

### `POST /api/inference`
Smart inference with multi-turn history, structured output, and system prompts.
Uses Anthropic Claude or OpenRouter.

```json
{
  "model": "anthropic/claude-sonnet-4",
  "prompt": "Analyse this script and give me 3 improvements",
  "options": {
    "systemPrompt": "You are a film director and creative director",
    "temperature": 0.7,
    "maxTokens": 4096,
    "history": [
      { "role": "user", "content": "Previous message..." },
      { "role": "assistant", "content": "Previous reply..." }
    ]
  },
  "userEmail": "user@example.com"
}
```

**Structured output** (returns JSON automatically):
```json
{
  "model": "anthropic/claude-sonnet-4",
  "prompt": "Extract the title and genre from this script",
  "options": {
    "outputSchema": {
      "type": "object",
      "properties": {
        "title": { "type": "string" },
        "genre": { "type": "string" },
        "mood": { "type": "string" }
      },
      "required": ["title", "genre"]
    }
  }
}
```

**OpenRouter free models** (no cost):
- `openrouter/llama-4-scout`
- `openrouter/deepseek-r1`
- `openrouter/gemini-flash`
- `openrouter/phi-4`

---

### `POST /api/sync`
Lip sync audio to video using Sync.so (your NBA Josh / Creator Factory video pipeline).

```json
{
  "videoUrl": "https://your-storage.com/avatar-video.mp4",
  "audioUrl": "https://your-storage.com/voiceover.mp3",
  "model": "syncso/sync-1.9.0-beta",
  "options": {
    "smooth": true,
    "fps": 25,
    "estimatedDuration": 30
  },
  "userEmail": "user@example.com"
}
```

**Fallback chain:** Sync.so → Replicate Wav2Lip → Replicate SadTalker

---

### `GET /api/health`
Shows all provider status and which keys are configured.

```json
{
  "status": "operational",
  "providers": [
    { "name": "Groq", "status": "✅ configured", "type": "text" },
    { "name": "Sync.so", "status": "❌ missing key", "type": "sync" }
  ],
  "summary": { "configured": 10, "missing": 4, "total": 14 }
}
```

---

### `GET /api/credits/:email`
Get a user's credit balance.

### `POST /api/deduct-credits`
Manually deduct credits (for custom usage flows).

```json
{ "email": "user@example.com", "creditsToDeduct": 50, "reason": "Image generation" }
```

### `GET /api/providers`
List all available models per type.

### `GET /api/pricing`
Credit costs per modality.

### `GET /api/profit-dashboard`
Revenue and profit stats from Supabase.

### `POST /webhooks/paystack`
Auto credit allocation on payment. Wired to your 60/40 split.

---

## Fallback System

Every route has a fallback chain. If the primary provider fails (rate limit, error, missing key), the next one fires automatically. Zero downtime.

```
Text:      Groq → Gemini → Mistral → OpenAI → Cohere → Together
Image:     Runware → Fal → Replicate → HuggingFace
Video:     Fal (Kling) → Replicate → RunPod
Audio:     ElevenLabs → Replicate → HuggingFace
Inference: Anthropic → OpenRouter
Sync:      Sync.so → Replicate Wav2Lip
```

To force a specific provider, set model explicitly: `"model": "gemini/flash-2.0"`
To let the system auto-select best available: omit `model` entirely.

---

## Credit Costs

| Type | Cost |
|------|------|
| Text | 1 credit / 1K tokens |
| Image | 40–60 credits / image |
| Video | 200 credits / second |
| Audio | 100 credits / minute |
| Inference | 2 credits / 1K tokens |
| Sync | 500 credits / minute of video |

**Credit allocation:** User pays ₦ via Paystack → 40% becomes credits, 60% is your profit.

---

## Free Tier Priority

These providers have free tiers and are prioritised first in fallback chains:

| Provider | Modality | Free Limit |
|----------|----------|------------|
| Groq | text | 1,500 req/day |
| Google AI Studio | text/inference | 1,500 req/day |
| Cohere | text | 1,000 req/month |
| Together AI | text | $1 free credit |
| HuggingFace | image/audio | Rate limited |
| OpenRouter | inference | Several free models |

---

## File Structure

```
creator-factory-orchestration/
├── server.js                  ← main entry point
├── routes/
│   ├── text.js                ← Groq, Gemini, Mistral, OpenAI, Cohere, Together
│   ├── image.js               ← Runware, Fal, Replicate, HuggingFace
│   ├── video.js               ← Kling (Fal), WAN, Replicate, RunPod
│   ├── audio.js               ← ElevenLabs, MusicGen, Bark, HuggingFace
│   ├── inference.js           ← Anthropic Claude + OpenRouter
│   ├── sync.js                ← Sync.so + Replicate Wav2Lip
│   └── health.js              ← provider status check
├── middleware/
│   └── credits.js             ← Supabase credit check + deduction
├── utils/
│   └── logger.js              ← request logging
├── .env.example               ← all 14 providers listed
├── package.json
└── README.md
```

---

## Deployment on Replit

1. Upload zip or paste files
2. Create `.env` from `.env.example`
3. Add at least: `GROQ_API_KEY` + `GOOGLE_AI_KEY` + `SUPABASE_URL` + `SUPABASE_KEY`
4. Run: `npm install && npm start`
5. Set Paystack webhook to: `https://your-replit-url/webhooks/paystack`

---

## Built by

**NBA Josh** — Out The Mud Records / Creator Factory  
Port Harcourt, Nigeria
